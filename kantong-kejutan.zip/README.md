# RepEAT

RepEAT adalah prototipe marketplace makanan surplus untuk membantu mengurangi food waste sekaligus memberi pilihan makanan yang lebih terjangkau.

## Identitas visual
- `Rep`: olive green (`#8b8934`)
- `EAT`: yellow (`#f0b840`)
- Warna lain pada antarmuka tetap menggunakan palet proyek yang sudah ada.

## Menjalankan di browser
Perlu Node.js dan Python 3.

```bash
npm test
npm run serve
```

Buka `http://localhost:8080`.

## Build APK Android lewat GitHub Actions
GitHub Actions sudah disiapkan di `.github/workflows/build-apk.yml`.

1. Buat repository GitHub baru.
2. Upload seluruh isi folder proyek ini ke root repository (bukan folder pembungkus `kantong-kejutan`).
3. Buka tab **Actions**.
4. Pilih **Build RepEAT Android APK** lalu klik **Run workflow**.
5. Setelah selesai, buka hasil workflow dan unduh artifact **repeat-debug-apk**.

Workflow juga berjalan otomatis ketika ada perubahan pada `www/`, `scripts/`, konfigurasi Capacitor, atau workflow build di branch `main`.

## Batasan prototipe
Proyek ini tetap menggunakan data demo lokal/offline. Autentikasi, pembayaran, dan transaksi nyata belum diaktifkan.
