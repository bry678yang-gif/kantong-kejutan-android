# Harmonize Report

Mode: **fix-testids + perubahan fitur yang diminta** (tidak ada `naming_conventions.md`, dipakai konvensi bawaan skill)
Proyek: HTML/CSS/JS murni (tanpa React), jadi aturan callback modal dan `useState` tidak berlaku langsung.

## Ringkasan

| Kategori | Sebelum | Sesudah | Risiko | Status |
|---|---|---|---|---|
| Elemen interaktif tanpa `data-testid` | 46 tag (button/input/select/textarea) + 43 `data-act`, **0** testid | **86** `data-testid` di template; diuji otomatis di 14 tampilan, 0 elemen tanpa testid | RENDAH | Selesai |
| Callback modal (`onClose`/`onSubmit`) | N/A (vanilla JS) | N/A | – | Tidak berlaku |
| Penamaan state error (`error`/`fieldErrors`) | state `flash` | tetap `flash` | RENDAH | WARNING, tidak diubah (hanya internal `app.js`, tidak diekspor; ganti nama tidak memberi manfaat uji) |
| Margin judul halaman (bug CSS) | `h2.tt` margin terhitung **0px** | margin 22px/21px sesuai desain | RENDAH | Selesai |

Format testid: `{komponen}-{jenis-elemen}[-{kualifier}]`, mis. `confirm-pay-btn`, `home-listing-row-L1`, `tdash-delete-btn-L3`, `bottom-nav-tab-orders`.

## Akar masalah padding/margin ("Buat Listing", "Dampak SDGs 12", "Pesanan Saya")

`.lh h2,h2.tt{margin:0}` (spesifisitas 0,1,1) mengalahkan `.tt{margin:2.2rem 2.1rem 1.2rem}` (0,1,0). Akibatnya semua judul `h2.tt` menempel ke tepi kiri dan rapat ke header. Aturan dipisah; judul dirapikan, subjudul Dampak memakai kelas `.sub-t` (sebelumnya margin `px` mentah di atribut `style`). Judul juga diseragamkan menjadi Title Case.

## Perubahan fitur

- **Pembayaran**: tab Kartu (validasi Luhn, masa berlaku, CVV; hanya 4 digit terakhir disimpan), QRIS (QR simulasi), Tunai (status "Bayar di tempat", otomatis "Lunas" saat diverifikasi).
- **Pengiriman**: Ambil di Toko atau Antar. Ongkir simulasi Rp4.000 + Rp2.000/km, dibulatkan per Rp500. Catatan untuk toko (maks 140 karakter). Alamat tersimpan dipakai otomatis.
- **Voucher**: input kode + pilihan dari Inventori; potongan nominal, persen (dengan batas), dan ongkir; minimal belanja; sekali pakai.
- **Profil pembeli** (ketuk avatar/nama): Pengaturan (nama, alamat, Cek Lokasi via GPS, atau Titik Contoh) dan Inventori voucher. Lokasi terverifikasi di Surabaya dipakai untuk menghitung jarak toko dan ongkir.
- **Tombol Back**: memakai riwayat browser; kembali ke tab sebelumnya, menutup menu/sheet/scanner lebih dulu. Dari halaman pesanan tidak kembali ke form bayar.
- **Tab Toko**: hanya dua kategori (Makanan, Paket Kejutan). Tombol "Lihat Semua" kini bergaya pill (sebelumnya `<button>` tanpa gaya).
- **Pencarian**: semua kata harus cocok di nama produk, toko, area/lokasi, kategori, harga, atau jarak. Ada di Beranda dan Toko.
- **QR Kode Ambil**: dibuat otomatis (`KK:` + kode) di halaman pesanan. Penjual: tombol Scan QR (kamera), Pilih Foto QR, atau Ketik Kode.
- **Penjual**: foto produk (dikecilkan ke maks 640 px) saat membuat listing atau diganti kapan saja; hapus listing.

## Keputusan yang perlu Anda ketahui

1. **Hapus listing ditolak jika masih ada pesanan berstatus Dipesan** (pembeli sudah bayar). Setelah diambil/hangus, listing bisa dihapus; riwayat pesanan dan angka dampak tetap ada.
2. **Scanner tidak bergantung `BarcodeDetector`** (tidak ada di WebView Android). Dipakai `BarcodeDetector` bila ada, selain itu pembaca QR buatan sendiri (`www/js/qrdecode.js`, tanpa internet). Hanya membaca QR buatan app ini (mode byte, koreksi galat M).
3. Koordinat toko, jarak, ongkir, kode voucher, dan nomor kartu uji adalah **data demo**.

## Belum diuji di perangkat nyata

Semua tes berjalan di Chromium desktop (kamera palsu, GPS palsu). Perlu dicoba di HP: tombol Back fisik (riwayat WebView), izin kamera dan lokasi, serta pemilih berkas foto. Lihat `README_APK.md`.

## Verifikasi

```bash
npm test            # 34 tes logika (termasuk QR encode/decode, voucher, kartu, hapus, foto)
npm run serve       # terminal lain
npm run test:ui     # 27 pemeriksaan alur lama
npm run test:fitur  # 43 pemeriksaan fitur baru (Back, checkout, profil, scan QR kamera, foto, hapus)
```
