# Membuat APK Kantong Kejutan (Android)

Seluruh aplikasi ada di folder `www/` (HTML/CSS/JS biasa, tanpa internet). Capacitor membungkusnya menjadi aplikasi Android.

## Yang perlu dipasang (sekali, di laptop)
1. **Node.js** versi LTS terbaru (nodejs.org)
2. **JDK 17 atau lebih baru** (Android Studio sudah menyertakannya)
3. **Android Studio** (developer.android.com/studio), lalu buka sekali dan biarkan ia mengunduh Android SDK

## Langkah (butuh internet hanya saat ini)
Buka terminal di folder proyek ini, lalu:

```bash
npm install @capacitor/core @capacitor/android @capacitor/local-notifications
npm install -D @capacitor/cli
npx cap add android
npx cap sync android
npx cap open android
```

Android Studio akan terbuka. Tunggu "Gradle sync" selesai (pertama kali bisa beberapa menit).

### Opsi A: langsung ke HP (paling mudah)
1. Di HP: Pengaturan > Tentang ponsel > ketuk **Nomor build** 7 kali > aktifkan **Opsi pengembang > Debugging USB**.
2. Colok HP ke laptop dengan kabel, izinkan debugging.
3. Di Android Studio pilih HP Anda di bagian atas, tekan tombol **Run** (segitiga hijau). Aplikasi terpasang dan terbuka.

### Opsi B: berkas APK untuk dikirim ke HP tim
1. Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
2. Setelah selesai, klik **locate**. Berkas ada di `android/app/build/outputs/apk/debug/app-debug.apk`.
3. Kirim ke HP (kabel, Drive, atau WhatsApp sebagai dokumen), buka, izinkan "pasang dari sumber ini".

APK debug cukup untuk demo lomba. Tidak perlu akun Google Play.

## Setelah mengubah kode di `www/`
```bash
npx cap sync android
```
lalu Run lagi di Android Studio.

## Mencoba di komputer dulu (tanpa Android)
```bash
npm run serve        # buka http://localhost:8080 di Chrome
npm test             # tes logika (CP-1 sampai CP-8)
```
Jangan membuka `www/index.html` dengan klik dua kali (file://); modul JavaScript butuh server lokal seperti di atas.

## Masalah umum
- **Gradle/JDK galat:** di Android Studio buka Settings > Build Tools > Gradle, pilih Gradle JDK versi 17+.
- **HP tidak terdeteksi:** ganti kabel (harus kabel data), pastikan Debugging USB aktif dan izinkan pop-up di HP.
- **Layar putih di HP:** jalankan `npx cap sync android` lagi, lalu Run ulang.

## Izin Android untuk fitur baru (kamera, lokasi, foto)

Setelah `npx cap add android`, buka `android/app/src/main/AndroidManifest.xml` dan pastikan ada (di dalam `<manifest>`, di luar `<application>`):

```xml
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
<uses-feature android:name="android.hardware.camera" android:required="false" />
```

- **Scan QR penjual** memakai kamera; pembaca QR sudah ada di dalam aplikasi (tanpa internet).
- **Cek Lokasi** pembeli memakai GPS; tanpa izin, pakai tombol "Titik Contoh" atau isi alamat manual.
- **Tombol Back** HP memakai riwayat WebView; dari layar awal tetap keluar aplikasi. Uji di HP: Beranda → Toko → Pesanan, lalu tekan Back dua kali.


## Notifikasi di Android (penting untuk fitur pengingat)

Notifikasi jam ambil, pengantaran, dan produk favorit selalu tampil **di dalam aplikasi** (ikon lonceng + banner). Agar juga muncul sebagai notifikasi sistem Android, termasuk saat aplikasi ditutup, aplikasi memakai plugin `@capacitor/local-notifications` (sudah ada di perintah `npm install` di atas; jalankan `npx cap sync android` setelahnya). Tambahkan juga di `AndroidManifest.xml`:

```xml
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
<uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" />
```

- Android 13+ akan menampilkan dialog izin notifikasi saat pengguna mengetuk **Izinkan** (sheet izin muncul sekali setelah memilih peran, atau lewat menu Izin Aplikasi).
- Pengingat yang dijadwalkan memakai jam simulasi; tombol **Majukan jam** menjadwal ulang otomatis.
- Pengantaran dan notifikasi antar-peran berjalan di satu perangkat (demo): notifikasi untuk Pembeli muncul saat peran Pembeli aktif. Aplikasi nyata membutuhkan server push (FCM) untuk mengirim antar perangkat.
- **Belum diuji di HP.** Jalur peramban (service worker) sudah diuji otomatis; jalur plugin native ditulis mengikuti dokumentasi plugin dan perlu dicoba di perangkat.
