# Membuat APK Kantong Kejutan (Android)

Seluruh aplikasi ada di folder `www/` (HTML/CSS/JS biasa, tanpa internet). Capacitor membungkusnya menjadi aplikasi Android.

## Yang perlu dipasang (sekali, di laptop)
1. **Node.js** versi LTS terbaru (nodejs.org)
2. **JDK 17 atau lebih baru** (Android Studio sudah menyertakannya)
3. **Android Studio** (developer.android.com/studio), lalu buka sekali dan biarkan ia mengunduh Android SDK

## Langkah (butuh internet hanya saat ini)
Buka terminal di folder proyek ini, lalu:

```bash
npm install @capacitor/core @capacitor/android
npm install -D @capacitor/cli
npx cap add android
npx cap sync android
npx cap open android
```

Android Studio akan terbuka. Tunggu "Gradle sync" selesai (pertama kali bisa beberapa menit).

### Opsi A: langsung ke HP (paling mudah)
1. Di HP: Pengaturan > Tentang ponsel > ketuk **Nomor build** 7 kali > aktifkan **Opsi pengembang > Debugging USB**.
2. Colok HP ke laptop dengan kabel, izinkan debugging.
3. Di Android Studio pilih HP Anda di bagian atas, tekan tombol **Run** (segitiga hijau). Aplikasi terpasang dan terbuka.

### Opsi B: berkas APK untuk dikirim ke HP tim
1. Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
2. Setelah selesai, klik **locate**. Berkas ada di `android/app/build/outputs/apk/debug/app-debug.apk`.
3. Kirim ke HP (kabel, Drive, atau WhatsApp sebagai dokumen), buka, izinkan "pasang dari sumber ini".

APK debug cukup untuk demo lomba. Tidak perlu akun Google Play.

## Setelah mengubah kode di `www/`
```bash
npx cap sync android
```
lalu Run lagi di Android Studio.

## Mencoba di komputer dulu (tanpa Android)
```bash
npm run serve        # buka http://localhost:8080 di Chrome
npm test             # tes logika (CP-1 sampai CP-8)
```
Jangan membuka `www/index.html` dengan klik dua kali (file://); modul JavaScript butuh server lokal seperti di atas.

## Masalah umum
- **Gradle/JDK galat:** di Android Studio buka Settings > Build Tools > Gradle, pilih Gradle JDK versi 17+.
- **HP tidak terdeteksi:** ganti kabel (harus kabel data), pastikan Debugging USB aktif dan izinkan pop-up di HP.
- **Layar putih di HP:** jalankan `npx cap sync android` lagi, lalu Run ulang.
