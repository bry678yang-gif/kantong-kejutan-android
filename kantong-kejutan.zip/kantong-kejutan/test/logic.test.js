import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  STATUS, seedState, validateListing, createListing, buyerView, activeListings,
  placeOrder, verifyCode, expireOrders, computeImpact, remainingStock, todayAt,
} from '../www/js/logic.js';

const NOW = new Date(2026, 10, 21, 15, 0, 0).getTime(); // 21 Nov 2026 15:00
const H = 3600000;

function rngFrom(seed) { let s = seed; return () => (s = (s * 1664525 + 1013904223) % 4294967296) / 4294967296; }
function fresh() { return seedState(NOW); }
function addListing(state, over = {}) {
  const r = createListing(state, 's1', { type: 'item', nama: 'Roti uji', jumlah: 10, harga: 5000,
    ambilStart: NOW + H, ambilEnd: NOW + 4 * H, ...over }, NOW);
  assert.ok(r.ok, JSON.stringify(r));
  return r.listing;
}

test('REQ-2.4 validasi: jumlah, harga, jendela', () => {
  const base = { type: 'kejutan', jumlah: 3, harga: 10000, ambilStart: NOW + H, ambilEnd: NOW + 3 * H };
  assert.equal(validateListing(base, NOW).ok, true);
  assert.equal(validateListing({ ...base, jumlah: 0 }, NOW).ok, false);
  assert.equal(validateListing({ ...base, jumlah: -2 }, NOW).ok, false);
  assert.equal(validateListing({ ...base, jumlah: 1.5 }, NOW).ok, false);
  assert.equal(validateListing({ ...base, harga: 0 }, NOW).ok, false);
  assert.equal(validateListing({ ...base, harga: -1 }, NOW).ok, false);
  assert.equal(validateListing({ ...base, ambilEnd: base.ambilStart }, NOW).ok, false);
  assert.equal(validateListing({ ...base, ambilEnd: NOW + 0.5 * H }, NOW).ok, false);
  assert.equal(validateListing({ ...base, ambilStart: NaN }, NOW).ok, false);
  assert.equal(validateListing({ ...base, ambilStart: NOW - 2 * H, ambilEnd: NOW - H }, NOW).ok, false);
});

test('REQ-2.2/2.3: Paket Kejutan tanpa nama; Item Pilihan wajib nama', () => {
  const base = { jumlah: 3, harga: 10000, ambilStart: NOW + H, ambilEnd: NOW + 3 * H };
  assert.equal(validateListing({ ...base, type: 'kejutan' }, NOW).ok, true);
  assert.equal(validateListing({ ...base, type: 'item', nama: '  ' }, NOW).ok, false);
  assert.equal(validateListing({ ...base, type: 'item', nama: 'Roti' }, NOW).ok, true);
  assert.equal(validateListing({ ...base, type: 'lain' }, NOW).ok, false);
});

test('listing yang tidak valid tidak disimpan', () => {
  const s = fresh(); const n = s.listings.length;
  const r = createListing(s, 's1', { type: 'kejutan', jumlah: 0, harga: 1000, ambilStart: NOW + H, ambilEnd: NOW + 2 * H }, NOW);
  assert.equal(r.ok, false);
  assert.equal(s.listings.length, n);
});

test('CP-1: stok = awal - total pesanan, tidak pernah < 0 (acak)', () => {
  const rng = rngFrom(42);
  for (let round = 0; round < 50; round++) {
    const s = fresh();
    const stokAwal = 1 + Math.floor(rng() * 30);
    const l = addListing(s, { jumlah: stokAwal });
    for (let i = 0; i < 40; i++) {
      placeOrder(s, l.id, Math.floor(rng() * 12) - 2, NOW, rng); // termasuk n <= 0 dan > stok
      assert.ok(l.stok >= 0);
      assert.equal(l.stok, remainingStock(l, s.orders));
    }
    assert.equal(l.stok, stokAwal - s.orders.filter(o => o.listingId === l.id).reduce((a, o) => a + o.qty, 0));
  }
});

test('REQ-5.1: n harus bilangan bulat 1..stok; stok tersedia disebutkan', () => {
  const s = fresh(); const l = addListing(s, { jumlah: 3 });
  for (const bad of [0, -1, 1.5, NaN, '2', 4]) {
    const r = placeOrder(s, l.id, bad, NOW);
    assert.equal(r.ok, false, `n=${bad}`);
  }
  assert.match(placeOrder(s, l.id, 4, NOW).error, /3/);
  assert.equal(l.stok, 3);
  assert.equal(s.orders.length, 0);
});

test('CP-2: total = harga satuan x jumlah (acak)', () => {
  const rng = rngFrom(7);
  for (let i = 0; i < 100; i++) {
    const s = fresh();
    const harga = 1000 + Math.floor(rng() * 90) * 500;
    const l = addListing(s, { jumlah: 20, harga });
    const n = 1 + Math.floor(rng() * 20);
    const r = placeOrder(s, l.id, n, NOW, rng);
    assert.equal(r.order.total, harga * n);
    assert.equal(r.order.unitPrice, harga);
  }
});

test('CP-3: Kode Ambil unik dan hanya sekali verifikasi', () => {
  const s = fresh(); const l = addListing(s, { jumlah: 600 });
  const rng = () => 0.1234; // rng buruk memaksa tabrakan; kode tetap harus unik
  for (let i = 0; i < 300; i++) assert.ok(placeOrder(s, l.id, 1, NOW, rng).ok);
  const codes = s.orders.map(o => o.code);
  assert.equal(new Set(codes).size, codes.length);
  const first = s.orders[0];
  assert.equal(verifyCode(s, first.storeId, first.code, NOW).ok, true);
  assert.equal(first.status, STATUS.DIAMBIL);
  const again = verifyCode(s, first.storeId, first.code, NOW);
  assert.equal(again.ok, false);
  assert.match(again.error, /sudah/i);
});

test('REQ-6.2: kode salah, huruf kecil/spasi dinormalisasi, toko lain ditolak', () => {
  const s = fresh(); const l = addListing(s);
  const o = placeOrder(s, l.id, 1, NOW).order;
  assert.equal(verifyCode(s, 's1', 'ZZZZZZ', NOW).ok, false);
  assert.equal(verifyCode(s, 's1', '', NOW).ok, false);
  assert.equal(verifyCode(s, 's2', o.code, NOW).ok, false);
  assert.equal(o.status, STATUS.DIPESAN);
  assert.equal(verifyCode(s, 's1', ` ${o.code.toLowerCase()} `, NOW).ok, true);
});

test('CP-4: pemesanan di luar Jendela Jual ditolak', () => {
  const s = fresh(); const l = addListing(s, { ambilEnd: NOW + 4 * H });
  assert.equal(placeOrder(s, l.id, 1, l.jualStart - 1).ok, false);
  assert.equal(placeOrder(s, l.id, 1, l.jualEnd + 1).ok, false);
  assert.equal(placeOrder(s, l.id, 1, l.jualEnd).ok, false);
  assert.equal(placeOrder(s, l.id, 1, l.jualStart).ok, true);
  assert.equal(l.stok, l.stokAwal - 1);
});

test('CP-5: transisi status hanya Dipesan->Diambil atau Dipesan->Hangus', () => {
  const s = fresh(); const l = addListing(s, { jumlah: 5 });
  const a = placeOrder(s, l.id, 1, NOW).order;
  const b = placeOrder(s, l.id, 2, NOW).order;
  verifyCode(s, 's1', a.code, NOW);
  const stokSebelum = l.stok;
  expireOrders(s, l.ambilEnd + 1);
  assert.equal(a.status, STATUS.DIAMBIL, 'Diambil tidak boleh menjadi Hangus');
  assert.equal(b.status, STATUS.HANGUS);
  assert.equal(l.stok, stokSebelum, 'stok tidak dikembalikan');
  assert.equal(verifyCode(s, 's1', b.code, l.ambilEnd + 1).ok, false);
  assert.equal(b.status, STATUS.HANGUS);
  expireOrders(s, l.ambilEnd + 2 * H);
  assert.equal(b.status, STATUS.HANGUS);
});

test('Hangus tepat setelah Jendela Ambil berakhir, bukan sebelumnya', () => {
  const s = fresh(); const l = addListing(s);
  const o = placeOrder(s, l.id, 1, NOW).order;
  expireOrders(s, l.ambilEnd);
  assert.equal(o.status, STATUS.DIPESAN);
  expireOrders(s, l.ambilEnd + 1);
  assert.equal(o.status, STATUS.HANGUS);
});

test('CP-6: tampilan Pembeli untuk Paket Kejutan tanpa harga coret/isi', () => {
  const s = fresh();
  const l = s.listings.find(x => x.type === 'kejutan');
  l.hargaAsli = 99999; l.isi = ['rahasia']; // data nakal tidak boleh bocor
  const v = buyerView(l, s.stores.find(x => x.id === l.storeId));
  const json = JSON.stringify(v);
  for (const k of ['hargaAsli', 'hargaCoret', 'isi', 'rahasia', '99999']) assert.ok(!json.includes(k), k);
  assert.equal(v.harga, l.harga);
  assert.equal(v.judul, 'Paket Kejutan');
});

test('REQ-4.2: Item Pilihan menampilkan nama dan harga', () => {
  const s = fresh(); const l = addListing(s, { nama: 'Roti Pisang', harga: 7000 });
  const v = buyerView(l, s.stores[0]);
  assert.equal(v.judul, 'Roti Pisang');
  assert.equal(v.harga, 7000);
});

test('REQ-3: daftar aktif urut jarak; sembunyikan stok 0 dan jendela berakhir', () => {
  const s = fresh();
  const list = activeListings(s, NOW);
  assert.ok(list.length >= 4);
  for (let i = 1; i < list.length; i++) assert.ok(list[i - 1].jarakKm <= list[i].jarakKm);
  const l = addListing(s, { jumlah: 1 });
  assert.ok(activeListings(s, NOW).some(x => x.id === l.id));
  placeOrder(s, l.id, 1, NOW);
  assert.ok(!activeListings(s, NOW).some(x => x.id === l.id), 'stok 0 disembunyikan');
  assert.equal(activeListings(s, NOW + 100 * H).length, 0, 'semua jendela berakhir');
});

test('REQ-2.5: listing baru tampil pada Pembeli di sesi yang sama', () => {
  const s = fresh(); const l = addListing(s);
  assert.ok(activeListings(s, NOW).some(x => x.id === l.id));
});

test('CP-7: dampak hanya dari pesanan Diambil', () => {
  const s = fresh(); const l = addListing(s, { jumlah: 10, harga: 6000 });
  const a = placeOrder(s, l.id, 2, NOW).order;
  placeOrder(s, l.id, 3, NOW);                 // tetap Dipesan
  const c = placeOrder(s, l.id, 1, NOW).order; // akan Hangus
  assert.deepEqual([computeImpact(s).unit, computeImpact(s).rupiah], [0, 0]);
  verifyCode(s, 's1', a.code, NOW);
  expireOrders(s, l.ambilEnd + 1);
  assert.equal(c.status, STATUS.HANGUS);
  const imp = computeImpact(s);
  assert.equal(imp.unit, 2);
  assert.equal(imp.rupiah, 12000);
  assert.ok(imp.co2Kg > 0);
  assert.match(imp.catatan, /estimasi|demo/i);
});

test('CP-8: Reset demo identik dengan dataset awal', () => {
  const awal = fresh();
  const s = fresh(); const l = addListing(s);
  placeOrder(s, l.id, 2, NOW); s.meta.offsetMs = 3 * H;
  const reset = seedState(NOW);
  assert.deepEqual(reset, awal);
  assert.notDeepEqual(s, awal);
});

test('REQ-1.2: data demo toko fiktif tanpa merek nyata', () => {
  const s = fresh();
  assert.ok(s.stores.length >= 4);
  const names = JSON.stringify(s.stores).toLowerCase();
  for (const m of ['bon ami', 'j.co', 'breadtalk', 'dunkin']) assert.ok(!names.includes(m), m);
  assert.ok(s.listings.some(l => l.type === 'kejutan') && s.listings.some(l => l.type === 'item'));
});

test('todayAt mengubah HH:MM menjadi waktu hari ini; input buruk NaN', () => {
  const t = todayAt('18:30', NOW);
  const d = new Date(t);
  assert.deepEqual([d.getFullYear(), d.getMonth(), d.getDate(), d.getHours(), d.getMinutes()], [2026, 10, 21, 18, 30]);
  assert.ok(Number.isNaN(todayAt('', NOW)));
  assert.ok(Number.isNaN(todayAt('25:99', NOW)));
});
