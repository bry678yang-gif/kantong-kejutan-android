import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  STATUS, seedState, validateListing, createListing, buyerView, activeListings,
  placeOrder, verifyCode, expireOrders, computeImpact, remainingStock, todayAt,
  deleteListing, setListingFoto, priceBreakdown, ongkirFor, applyVoucher, addVoucher, validateCard, luhnOk, migrateState,
  updateBuyer, storeDistance, inSurabaya, parseCodeInput, VOUCHER_KATALOG,
} from '../www/js/logic.js';
import { qrMatrix } from '../www/js/qr.js';
import { decodeMatrix } from '../www/js/qrdecode.js';

const NOW = new Date(2026, 10, 21, 15, 0, 0).getTime(); // 21 Nov 2026 15:00
const H = 3600000;

function rngFrom(seed) { let s = seed; return () => (s = (s * 1664525 + 1013904223) % 4294967296) / 4294967296; }
function fresh() { return seedState(NOW); }
function addListing(state, over = {}) {
  const r = createListing(state, 's1', { type: 'item', nama: 'Roti uji', jumlah: 10, harga: 5000,
    ambilStart: NOW + H, ambilEnd: NOW + 4 * H, ...over }, NOW);
  assert.ok(r.ok, JSON.stringify(r));
  return r.listing;
}

test('REQ-2.4 validasi: jumlah, harga, jendela', () => {
  const base = { type: 'kejutan', jumlah: 3, harga: 10000, ambilStart: NOW + H, ambilEnd: NOW + 3 * H };
  assert.equal(validateListing(base, NOW).ok, true);
  assert.equal(validateListing({ ...base, jumlah: 0 }, NOW).ok, false);
  assert.equal(validateListing({ ...base, jumlah: -2 }, NOW).ok, false);
  assert.equal(validateListing({ ...base, jumlah: 1.5 }, NOW).ok, false);
  assert.equal(validateListing({ ...base, harga: 0 }, NOW).ok, false);
  assert.equal(validateListing({ ...base, harga: -1 }, NOW).ok, false);
  assert.equal(validateListing({ ...base, ambilEnd: base.ambilStart }, NOW).ok, false);
  assert.equal(validateListing({ ...base, ambilEnd: NOW + 0.5 * H }, NOW).ok, false);
  assert.equal(validateListing({ ...base, ambilStart: NaN }, NOW).ok, false);
  assert.equal(validateListing({ ...base, ambilStart: NOW - 2 * H, ambilEnd: NOW - H }, NOW).ok, false);
});

test('REQ-2.2/2.3: Paket Kejutan tanpa nama; Item Pilihan wajib nama', () => {
  const base = { jumlah: 3, harga: 10000, ambilStart: NOW + H, ambilEnd: NOW + 3 * H };
  assert.equal(validateListing({ ...base, type: 'kejutan' }, NOW).ok, true);
  assert.equal(validateListing({ ...base, type: 'item', nama: '  ' }, NOW).ok, false);
  assert.equal(validateListing({ ...base, type: 'item', nama: 'Roti' }, NOW).ok, true);
  assert.equal(validateListing({ ...base, type: 'lain' }, NOW).ok, false);
});

test('listing yang tidak valid tidak disimpan', () => {
  const s = fresh(); const n = s.listings.length;
  const r = createListing(s, 's1', { type: 'kejutan', jumlah: 0, harga: 1000, ambilStart: NOW + H, ambilEnd: NOW + 2 * H }, NOW);
  assert.equal(r.ok, false);
  assert.equal(s.listings.length, n);
});

test('CP-1: stok = awal - total pesanan, tidak pernah < 0 (acak)', () => {
  const rng = rngFrom(42);
  for (let round = 0; round < 50; round++) {
    const s = fresh();
    const stokAwal = 1 + Math.floor(rng() * 30);
    const l = addListing(s, { jumlah: stokAwal });
    for (let i = 0; i < 40; i++) {
      placeOrder(s, l.id, Math.floor(rng() * 12) - 2, NOW, rng); // termasuk n <= 0 dan > stok
      assert.ok(l.stok >= 0);
      assert.equal(l.stok, remainingStock(l, s.orders));
    }
    assert.equal(l.stok, stokAwal - s.orders.filter(o => o.listingId === l.id).reduce((a, o) => a + o.qty, 0));
  }
});

test('REQ-5.1: n harus bilangan bulat 1..stok; stok tersedia disebutkan', () => {
  const s = fresh(); const l = addListing(s, { jumlah: 3 });
  for (const bad of [0, -1, 1.5, NaN, '2', 4]) {
    const r = placeOrder(s, l.id, bad, NOW);
    assert.equal(r.ok, false, `n=${bad}`);
  }
  assert.match(placeOrder(s, l.id, 4, NOW).error, /3/);
  assert.equal(l.stok, 3);
  assert.equal(s.orders.length, 0);
});

test('CP-2: total = harga satuan x jumlah (acak)', () => {
  const rng = rngFrom(7);
  for (let i = 0; i < 100; i++) {
    const s = fresh();
    const harga = 1000 + Math.floor(rng() * 90) * 500;
    const l = addListing(s, { jumlah: 20, harga });
    const n = 1 + Math.floor(rng() * 20);
    const r = placeOrder(s, l.id, n, NOW, rng);
    assert.equal(r.order.total, harga * n);
    assert.equal(r.order.unitPrice, harga);
  }
});

test('CP-3: Kode Ambil unik dan hanya sekali verifikasi', () => {
  const s = fresh(); const l = addListing(s, { jumlah: 600 });
  const rng = () => 0.1234; // rng buruk memaksa tabrakan; kode tetap harus unik
  for (let i = 0; i < 300; i++) assert.ok(placeOrder(s, l.id, 1, NOW, rng).ok);
  const codes = s.orders.map(o => o.code);
  assert.equal(new Set(codes).size, codes.length);
  const first = s.orders[0];
  assert.equal(verifyCode(s, first.storeId, first.code, NOW).ok, true);
  assert.equal(first.status, STATUS.DIAMBIL);
  const again = verifyCode(s, first.storeId, first.code, NOW);
  assert.equal(again.ok, false);
  assert.match(again.error, /sudah/i);
});

test('REQ-6.2: kode salah, huruf kecil/spasi dinormalisasi, toko lain ditolak', () => {
  const s = fresh(); const l = addListing(s);
  const o = placeOrder(s, l.id, 1, NOW).order;
  assert.equal(verifyCode(s, 's1', 'ZZZZZZ', NOW).ok, false);
  assert.equal(verifyCode(s, 's1', '', NOW).ok, false);
  assert.equal(verifyCode(s, 's2', o.code, NOW).ok, false);
  assert.equal(o.status, STATUS.DIPESAN);
  assert.equal(verifyCode(s, 's1', ` ${o.code.toLowerCase()} `, NOW).ok, true);
});

test('CP-4: pemesanan di luar Jendela Jual ditolak', () => {
  const s = fresh(); const l = addListing(s, { ambilEnd: NOW + 4 * H });
  assert.equal(placeOrder(s, l.id, 1, l.jualStart - 1).ok, false);
  assert.equal(placeOrder(s, l.id, 1, l.jualEnd + 1).ok, false);
  assert.equal(placeOrder(s, l.id, 1, l.jualEnd).ok, false);
  assert.equal(placeOrder(s, l.id, 1, l.jualStart).ok, true);
  assert.equal(l.stok, l.stokAwal - 1);
});

test('CP-5: transisi status hanya Dipesan->Diambil atau Dipesan->Hangus', () => {
  const s = fresh(); const l = addListing(s, { jumlah: 5 });
  const a = placeOrder(s, l.id, 1, NOW).order;
  const b = placeOrder(s, l.id, 2, NOW).order;
  verifyCode(s, 's1', a.code, NOW);
  const stokSebelum = l.stok;
  expireOrders(s, l.ambilEnd + 1);
  assert.equal(a.status, STATUS.DIAMBIL, 'Diambil tidak boleh menjadi Hangus');
  assert.equal(b.status, STATUS.HANGUS);
  assert.equal(l.stok, stokSebelum, 'stok tidak dikembalikan');
  assert.equal(verifyCode(s, 's1', b.code, l.ambilEnd + 1).ok, false);
  assert.equal(b.status, STATUS.HANGUS);
  expireOrders(s, l.ambilEnd + 2 * H);
  assert.equal(b.status, STATUS.HANGUS);
});

test('Hangus tepat setelah Jendela Ambil berakhir, bukan sebelumnya', () => {
  const s = fresh(); const l = addListing(s);
  const o = placeOrder(s, l.id, 1, NOW).order;
  expireOrders(s, l.ambilEnd);
  assert.equal(o.status, STATUS.DIPESAN);
  expireOrders(s, l.ambilEnd + 1);
  assert.equal(o.status, STATUS.HANGUS);
});

test('CP-6: tampilan Pembeli untuk Paket Kejutan tanpa harga coret/isi', () => {
  const s = fresh();
  const l = s.listings.find(x => x.type === 'kejutan');
  l.hargaAsli = 99999; l.isi = ['rahasia']; // data nakal tidak boleh bocor
  const v = buyerView(l, s.stores.find(x => x.id === l.storeId));
  const json = JSON.stringify(v);
  for (const k of ['hargaAsli', 'hargaCoret', 'isi', 'rahasia', '99999']) assert.ok(!json.includes(k), k);
  assert.equal(v.harga, l.harga);
  assert.equal(v.judul, 'Paket Kejutan');
});

test('REQ-4.2: Item Pilihan menampilkan nama dan harga', () => {
  const s = fresh(); const l = addListing(s, { nama: 'Roti Pisang', harga: 7000 });
  const v = buyerView(l, s.stores[0]);
  assert.equal(v.judul, 'Roti Pisang');
  assert.equal(v.harga, 7000);
});

test('REQ-3: daftar aktif urut jarak; sembunyikan stok 0 dan jendela berakhir', () => {
  const s = fresh();
  const list = activeListings(s, NOW);
  assert.ok(list.length >= 4);
  for (let i = 1; i < list.length; i++) assert.ok(list[i - 1].jarakKm <= list[i].jarakKm);
  const l = addListing(s, { jumlah: 1 });
  assert.ok(activeListings(s, NOW).some(x => x.id === l.id));
  placeOrder(s, l.id, 1, NOW);
  assert.ok(!activeListings(s, NOW).some(x => x.id === l.id), 'stok 0 disembunyikan');
  assert.equal(activeListings(s, NOW + 100 * H).length, 0, 'semua jendela berakhir');
});

test('REQ-2.5: listing baru tampil pada Pembeli di sesi yang sama', () => {
  const s = fresh(); const l = addListing(s);
  assert.ok(activeListings(s, NOW).some(x => x.id === l.id));
});

test('CP-7: dampak hanya dari pesanan Diambil', () => {
  const s = fresh(); const l = addListing(s, { jumlah: 10, harga: 6000 });
  const a = placeOrder(s, l.id, 2, NOW).order;
  placeOrder(s, l.id, 3, NOW);                 // tetap Dipesan
  const c = placeOrder(s, l.id, 1, NOW).order; // akan Hangus
  assert.deepEqual([computeImpact(s).unit, computeImpact(s).rupiah], [0, 0]);
  verifyCode(s, 's1', a.code, NOW);
  expireOrders(s, l.ambilEnd + 1);
  assert.equal(c.status, STATUS.HANGUS);
  const imp = computeImpact(s);
  assert.equal(imp.unit, 2);
  assert.equal(imp.rupiah, 12000);
  assert.ok(imp.co2Kg > 0);
  assert.match(imp.catatan, /estimasi|demo/i);
});

test('CP-8: Reset demo identik dengan dataset awal', () => {
  const awal = fresh();
  const s = fresh(); const l = addListing(s);
  placeOrder(s, l.id, 2, NOW); s.meta.offsetMs = 3 * H;
  const reset = seedState(NOW);
  assert.deepEqual(reset, awal);
  assert.notDeepEqual(s, awal);
});

test('REQ-1.2: merchant demo = J.CO, Bon Ami, Holland, dan 3 hotel Surabaya, masing-masing punya produk', () => {
  const s = fresh();
  assert.equal(s.stores.length, 6);
  const names = s.stores.map(x => x.nama.toLowerCase());
  for (const m of ['j.co', 'bon ami', 'holland']) assert.ok(names.some(n => n.includes(m)), m);
  assert.equal(names.filter(n => n.includes('hotel')).length, 3);
  for (const st of s.stores) {
    const ls = s.listings.filter(l => l.storeId === st.id);
    assert.ok(ls.some(l => l.type === 'kejutan') && ls.some(l => l.type === 'item'), st.nama);
  }
  assert.equal(s.listings.length, 18);
});

test('todayAt mengubah HH:MM menjadi waktu hari ini; input buruk NaN', () => {
  const t = todayAt('18:30', NOW);
  const d = new Date(t);
  assert.deepEqual([d.getFullYear(), d.getMonth(), d.getDate(), d.getHours(), d.getMinutes()], [2026, 10, 21, 18, 30]);
  assert.ok(Number.isNaN(todayAt('', NOW)));
  assert.ok(Number.isNaN(todayAt('25:99', NOW)));
});


// ---------- Fitur baru: checkout, voucher, ongkir, kartu, QR, foto, hapus ----------
const FOTO = 'data:image/jpeg;base64,/9j/4AAQSkZJRg==';
const CARD = { metode: 'kartu', nomor: '4242 4242 4242 4242', exp: '12/30', cvv: '123' };
const opts = (o = {}) => ({ metode: 'ambil', alamat: '', catatan: '', voucherCode: '', bayar: CARD, ...o });

test('ongkir: Rp4.000 + Rp2.000/km, dibulatkan ke atas per Rp500', () => {
  assert.equal(ongkirFor(0), 4000); assert.equal(ongkirFor(1), 6000); assert.equal(ongkirFor(1.6), 7500); assert.equal(ongkirFor(0.6), 5500);
});

test('voucher: nominal, persen (maks), ongkir; minimal belanja; sekali pakai', () => {
  const V = c => ({ ...VOUCHER_KATALOG.find(v => v.code === c), dipakai: false });
  assert.deepEqual(applyVoucher(V('HEMAT5K'), 25000, 0), { ok: true, diskon: 5000 });
  assert.equal(applyVoucher(V('HEMAT5K'), 15000, 0).ok, false);              // di bawah minimal
  assert.deepEqual(applyVoucher(V('SDG12'), 50000, 0), { ok: true, diskon: 5000 });
  assert.equal(applyVoucher(V('SDG12'), 200000, 0).diskon, 10000);            // dibatasi maks
  assert.equal(applyVoucher(V('ONGKIR0'), 25000, 0).ok, false);               // tanpa ongkir
  assert.equal(applyVoucher(V('ONGKIR0'), 25000, 7500).diskon, 7500);         // tidak melebihi ongkir
  assert.equal(applyVoucher({ ...V('HEMAT5K'), dipakai: true }, 25000, 0).ok, false);
  assert.equal(applyVoucher(V('HEMAT5K'), 3000 * 0 + 20000, 0).diskon, 5000); // tepat di batas minimal
});

test('addVoucher: kode dikenal masuk inventori, duplikat/ngawur ditolak', () => {
  const s = fresh(); const n = s.buyer.vouchers.length;
  assert.equal(addVoucher(s, 'ngawur').ok, false); assert.equal(addVoucher(s, '').ok, false);
  assert.equal(addVoucher(s, 'hemat5k').ok, false);                           // sudah ada
  assert.equal(addVoucher(s, ' sdg12 ').ok, true); assert.equal(s.buyer.vouchers.length, n + 1);
  assert.equal(addVoucher(s, 'SDG12').ok, false);
});

test('kartu: Luhn, masa berlaku, CVV; hanya 4 digit terakhir yang disimpan', () => {
  assert.equal(luhnOk('4242424242424242'), true); assert.equal(luhnOk('4242424242424243'), false);
  assert.equal(validateCard(CARD, NOW).ok, true);
  assert.equal(validateCard({ ...CARD, exp: '01/20' }, NOW).ok, false); assert.equal(validateCard({ ...CARD, exp: '13/30' }, NOW).ok, false);
  assert.equal(validateCard({ ...CARD, cvv: '12' }, NOW).ok, false);
  const s = fresh(); const r = placeOrder(s, 'L1', 1, NOW, Math.random, opts());
  assert.equal(r.order.kartu4, '4242'); assert.doesNotMatch(JSON.stringify(s), /4242 ?4242 ?4242/);
});

test('placeOrder lengkap: antar + voucher + catatan, total = subtotal + ongkir − diskon', () => {
  const s = fresh(); updateBuyer(s, { alamat: 'Jl. Uji 1' });
  const r = placeOrder(s, 'L1', 2, NOW, Math.random, opts({ metode: 'antar', alamat: 'Jl. Uji 1', voucherCode: 'HEMAT5K', catatan: ' tanpa kacang ' }));
  assert.ok(r.ok, JSON.stringify(r)); const o = r.order;
  assert.equal(o.subtotal, 50000); assert.equal(o.ongkir, ongkirFor(0.6)); assert.equal(o.diskon, 5000);
  assert.equal(o.total, 50000 + ongkirFor(0.6) - 5000); assert.equal(o.catatan, 'tanpa kacang'); assert.equal(o.metode, 'antar');
  assert.equal(s.buyer.vouchers.find(v => v.code === 'HEMAT5K').dipakai, true);
  assert.equal(placeOrder(s, 'L1', 1, NOW, Math.random, opts({ voucherCode: 'HEMAT5K' })).ok, false); // voucher sekali pakai
});

test('placeOrder: validasi masukan tidak mengurangi stok dan tidak memakai voucher', () => {
  const s = fresh(); const stok = s.listings[0].stok;
  const antarTanpaAlamat = placeOrder(s, 'L1', 1, NOW, Math.random, opts({ metode: 'antar', alamat: '' }));
  assert.equal(antarTanpaAlamat.ok, false); assert.equal(antarTanpaAlamat.kind, 'input');
  assert.equal(placeOrder(s, 'L1', 1, NOW, Math.random, opts({ voucherCode: 'ONGKIR0' })).ok, false); // ongkir0 untuk ambil sendiri
  assert.equal(placeOrder(s, 'L1', 1, NOW, Math.random, opts({ bayar: { metode: 'kartu', nomor: '1', exp: '', cvv: '' } })).ok, false);
  assert.equal(placeOrder(s, 'L1', 1, NOW, Math.random, opts({ bayar: { metode: 'bitcoin' } })).ok, false);
  assert.equal(placeOrder(s, 'L1', 1, NOW, Math.random, opts({ catatan: 'x'.repeat(141) })).ok, false);
  assert.equal(s.listings[0].stok, stok); assert.equal(s.orders.length, 0);
  assert.equal(s.buyer.vouchers.every(v => !v.dipakai), true);
});

test('tunai: status "Bayar di tempat" lalu "Lunas" saat diverifikasi; QRIS langsung Lunas', () => {
  const s = fresh();
  const a = placeOrder(s, 'L1', 1, NOW, Math.random, opts({ bayar: { metode: 'tunai' } })).order;
  const b = placeOrder(s, 'L1', 1, NOW, Math.random, opts({ bayar: { metode: 'qris' } })).order;
  assert.equal(a.statusBayar, 'Bayar di tempat'); assert.equal(b.statusBayar, 'Lunas');
  assert.equal(verifyCode(s, 's1', a.code, NOW).ok, true); assert.equal(a.statusBayar, 'Lunas');
});

test('verifyCode menerima isi QR "KK:KODE" dan huruf kecil; kode toko lain ditolak', () => {
  const s = fresh(); const o = placeOrder(s, 'L1', 1, NOW).order;
  assert.equal(parseCodeInput(' kk:' + o.code.toLowerCase() + ' '), o.code);
  assert.equal(verifyCode(s, 's2', 'KK:' + o.code, NOW).ok, false);
  assert.equal(verifyCode(s, 's1', 'KK:' + o.code, NOW).ok, true);
});

test('QR: isi "KK:KODE" bisa di-encode lalu di-decode untuk 300 kode acak', () => {
  const rng = rngFrom(99); const AL = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  for (let i = 0; i < 300; i++) {
    const code = Array.from({ length: 6 }, () => AL[Math.floor(rng() * 32)]).join('');
    assert.equal(decodeMatrix(qrMatrix('KK:' + code)), 'KK:' + code);
  }
  assert.equal(decodeMatrix(qrMatrix('Halo é ✓ ' + 'z'.repeat(150))), 'Halo é ✓ ' + 'z'.repeat(150)); // versi besar + UTF-8
});

test('QR: koreksi galat memperbaiki modul yang rusak', () => {
  const m = qrMatrix('KK:K7H2PQ').map(r => r.slice());
  for (let i = 0; i < 6; i++) m[12 + i][13] = !m[12 + i][13];
  assert.equal(decodeMatrix(m), 'KK:K7H2PQ');
});

test('hapus listing: hanya milik toko itu, ditolak bila ada pesanan Dipesan', () => {
  const s = fresh(); const n = s.listings.length;
  assert.equal(deleteListing(s, 's2', 'L1').ok, false);                       // bukan toko pemilik
  assert.equal(deleteListing(s, 's1', 'LX').ok, false);
  const o = placeOrder(s, 'L1', 1, NOW).order;
  const blocked = deleteListing(s, 's1', 'L1'); assert.equal(blocked.ok, false); assert.match(blocked.error, /1 pesanan/);
  verifyCode(s, 's1', o.code, NOW);                                           // selesai diambil -> boleh dihapus
  assert.equal(deleteListing(s, 's1', 'L1').ok, true); assert.equal(s.listings.length, n - 1);
  assert.equal(s.orders.length, 1);                                           // riwayat pesanan tetap ada
  assert.equal(computeImpact(s).unit, 1);
});

test('foto produk: hanya data URL gambar & ukuran wajar; tampil di buyerView', () => {
  const s = fresh();
  const base = { type: 'item', nama: 'Roti Foto', jumlah: 2, harga: 5000, ambilStart: NOW + H, ambilEnd: NOW + 3 * H };
  assert.equal(validateListing({ ...base, foto: FOTO }, NOW).ok, true);
  assert.equal(validateListing({ ...base, foto: 'http://evil.example/x.jpg' }, NOW).ok, false);
  assert.equal(validateListing({ ...base, foto: 'data:text/html;base64,PHNjcmlwdD4=' }, NOW).ok, false);
  assert.equal(validateListing({ ...base, foto: 'data:image/jpeg;base64,' + 'A'.repeat(400001) }, NOW).ok, false);
  const l = createListing(s, 's1', { ...base, foto: FOTO }, NOW).listing;
  assert.equal(activeListings(s, NOW).find(x => x.id === l.id).foto, FOTO);
  assert.equal(setListingFoto(s, 's1', 'L1', FOTO).ok, true); assert.equal(setListingFoto(s, 's2', 'L1', FOTO).ok, false);
  assert.equal(setListingFoto(s, 's1', 'L1', null).ok, true); assert.equal(s.listings[0].foto, null);
});

test('lokasi pembeli: jarak dihitung dari koordinat bila di Surabaya; di luar Surabaya tetap data contoh', () => {
  const s = fresh(); const st = s.stores[0];
  assert.equal(storeDistance(st, s.buyer), 0.6);
  updateBuyer(s, { lat: -7.2625, lng: 112.7381 }); assert.equal(s.buyer.lokasiOk, true);
  assert.equal(storeDistance(st, s.buyer), 1.6);
  updateBuyer(s, { lat: -6.2, lng: 106.8 }); assert.equal(s.buyer.lokasiOk, false); assert.equal(storeDistance(st, s.buyer), 0.6);
  assert.equal(inSurabaya(-7.26, 112.74), true); assert.equal(inSurabaya(-6.2, 106.8), false);
  assert.equal(updateBuyer(s, { nama: '  ' }).ok, false); assert.equal(updateBuyer(s, { nama: 'Budi' }).ok, true); assert.equal(s.buyer.nama, 'Budi');
});

test('migrateState: data lama (tanpa buyer/koordinat) dilengkapi, data baru tidak berubah', () => {
  const old = fresh(); delete old.buyer; old.stores.forEach(x => { delete x.lat; delete x.lng; });
  migrateState(old); assert.equal(old.buyer.nama, 'Pembeli Demo'); assert.equal(old.buyer.vouchers.length, 2); assert.ok(Number.isFinite(old.stores[0].lat));
  const cur = fresh(); const snap = JSON.stringify(cur); migrateState(cur); assert.equal(JSON.stringify(cur), snap);
});

test('priceBreakdown murni: tidak mengubah state', () => {
  const s = fresh(); const snap = JSON.stringify(s);
  priceBreakdown(s, s.listings[0], 2, { metode: 'antar', voucherCode: 'HEMAT5K' });
  assert.equal(JSON.stringify(s), snap);
});
