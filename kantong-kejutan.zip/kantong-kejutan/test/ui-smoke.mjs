// Uji asap UI di browser sungguhan (Layer 2). Jalankan: npm run serve (terminal lain) lalu node test/ui-smoke.mjs
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
let chromium;
try { ({ chromium } = require('playwright')); } catch { ({ chromium } = require('/opt/npm-tools/node_modules/playwright')); }
import assert from 'node:assert/strict';

const BASE = process.env.BASE || 'http://localhost:8080/';
const browser = await chromium.launch();
const page = await (await browser.newContext({ viewport: { width: 390, height: 800 } })).newPage();
const errors = [], external = [];
page.on('pageerror', e => errors.push(e.message));
page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
page.on('request', r => { if (!r.url().startsWith(BASE) && !r.url().startsWith('data:')) external.push(r.url()); });
const text = () => page.locator('#app').innerText();
const click = sel => page.locator(sel).first().click();
let step = 0; const ok = m => console.log(`ok ${++step} - ${m}`);

await page.goto(BASE);
assert.match(await text(), /MODE DEMO/); ok('layar awal + banner demo');

// Pembeli memesan Paket Kejutan terdekat
await click('[data-role=pembeli]');
assert.match(await text(), /Roti Bahagia Darmo/);
await click('.card.tap'); // listing terdekat
let t = await text();
assert.match(t, /Paket Kejutan/); assert.doesNotMatch(t, /coret|harga asli/i); ok('detail Paket Kejutan tanpa harga coret/isi');
await page.fill('#qty', '2');
assert.match(await page.locator('#totalTxt').innerText(), /30\.000/); ok('total = harga x jumlah (Rp30.000)');
await page.fill('#qty', '99'); await click('[data-act=toConfirm]');
assert.match(await text(), /Stok tersedia hanya 5/); ok('jumlah > stok ditolak dengan info stok');
await page.fill('#qty', '2'); await click('[data-act=toConfirm]');
assert.match(await text(), /SIMULASI/); await click('[data-act=pay]');
const code = (await page.locator('.code').innerText()).trim();
assert.match(code, /^[A-Z2-9]{6}$/); ok(`kode ambil dibuat: ${code}`);

// Toko memverifikasi
await click('[data-act=roles]'); await click('[data-role=toko]');
await page.fill('#kode', 'SALAH1'); await click('[data-act=verify]');
assert.match(await text(), /tidak ditemukan/); ok('kode salah ditolak');
await page.fill('#kode', code.toLowerCase()); await click('[data-act=verify]');
assert.match(await text(), /Berhasil/); ok('kode benar -> Diambil');
await page.fill('#kode', code); await click('[data-act=verify]');
assert.match(await text(), /sudah dipakai/); ok('kode dipakai ulang ditolak');

// Toko buat listing (tidak valid lalu valid)
await click('[data-to=tcreate]'); await page.fill('#f_jumlah', '0'); await click('[data-act=saveListing]');
assert.match(await text(), /Jumlah harus/); ok('listing jumlah 0 ditolak');
await click('[data-type=item]'); await page.fill('#f_nama', '<b>Roti Uji</b>'); await page.fill('#f_jumlah', '4'); await page.fill('#f_harga', '7000');
await click('[data-act=saveListing]');
assert.match(await text(), /Listing saya/); ok('listing valid disimpan');
assert.equal(await page.locator('#app b', { hasText: 'Roti Uji' }).count() >= 0, true);
assert.doesNotMatch(await page.locator('#app').innerHTML(), /<b>Roti Uji<\/b>/); ok('input toko di-escape (anti-XSS)');

// Pembeli melihat listing baru, memesan, lalu Hangus
await click('[data-act=roles]'); await click('[data-role=pembeli]');
assert.match(await text(), /Roti Uji/); ok('listing baru tampil untuk Pembeli');
await page.locator('.card.tap', { hasText: 'Roti Uji' }).click(); await click('[data-act=toConfirm]'); await click('[data-act=pay]');
for (let i = 0; i < 5; i++) await click('[data-act=advance]');
await click('[data-to=orders]');
assert.match(await text(), /Hangus/); ok('pesanan tidak diambil menjadi Hangus');

// Dampak: hanya pesanan Diambil (2 kantong, Rp30.000)
await click('[data-to=impact]'); t = await text();
assert.match(t, /\b2\b/); assert.match(t, /30\.000/); assert.match(t, /estimasi/i); ok('dampak dihitung dari pesanan Diambil saja');

// Data lokal tersimpan setelah muat ulang
await page.reload(); assert.match(await text(), /Dampak SDG 12|Dekat Anda|Pesanan saya/); ok('data bertahan setelah muat ulang');

// Reset
page.once('dialog', d => d.accept());
await click('[data-act=reset]'); assert.match(await text(), /Selamat datang/);
await click('[data-role=pembeli]');
assert.equal(await page.locator('.card.tap').count(), 6); ok('Reset demo mengembalikan 6 listing awal');

// Data rusak
await page.evaluate(() => localStorage.setItem('kk_demo_v1', '{rusak'));
await page.reload(); assert.match(await text(), /Data lokal rusak/);
await click('[data-act=reset]'); assert.match(await text(), /Selamat datang/); ok('data rusak -> layar Reset demo berfungsi');

assert.deepEqual(external, [], 'tidak boleh ada permintaan keluar'); ok('tanpa permintaan jaringan eksternal (offline-ready)');
assert.deepEqual(errors, [], 'galat konsol: ' + errors.join(' | ')); ok('tanpa galat JavaScript');
await browser.close();
