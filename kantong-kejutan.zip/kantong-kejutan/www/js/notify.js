// Izin perangkat (lokasi, kamera, notifikasi) dan notifikasi sistem.
// Di APK Capacitor memakai plugin @capacitor/local-notifications (bisa tampil saat aplikasi ditutup).
// Di peramban memakai Notification API lewat service worker. Tanpa izin, notifikasi tetap muncul di dalam aplikasi.
const plugins = () => (window.Capacitor && window.Capacitor.Plugins) || {};
const isNative = () => !!(window.Capacitor && typeof window.Capacitor.isNativePlatform === 'function' && window.Capacitor.isNativePlatform());
const LN = () => (isNative() ? plugins().LocalNotifications : null);
const norm = s => (s === 'granted' ? 'granted' : s === 'denied' ? 'denied' : 'prompt');

export const PERM_KINDS = ['lokasi', 'kamera', 'notifikasi'];

export async function queryPerm(kind) {
  try {
    if (kind === 'notifikasi') {
      if (LN()) return norm((await LN().checkPermissions()).display);
      return 'Notification' in window ? norm(Notification.permission) : 'unsupported';
    }
    if (kind === 'lokasi' && !navigator.geolocation) return 'unsupported';
    if (kind === 'kamera' && !(navigator.mediaDevices && navigator.mediaDevices.getUserMedia)) return 'unsupported';
    if (navigator.permissions && navigator.permissions.query) {
      const r = await navigator.permissions.query({ name: kind === 'lokasi' ? 'geolocation' : 'camera' });
      return norm(r.state);
    }
  } catch (e) { /* peramban tidak mendukung query izin: anggap belum ditanya */ }
  return 'prompt';
}

// Minta izin lewat dialog sistem. Harus dipanggil dari ketukan pengguna.
export async function requestPerm(kind) {
  try {
    if (kind === 'lokasi') {
      await new Promise((ok, no) => navigator.geolocation.getCurrentPosition(ok, no, { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }));
    } else if (kind === 'kamera') {
      const st = await navigator.mediaDevices.getUserMedia({ video: true, audio: false }); st.getTracks().forEach(t => t.stop());
    } else if (kind === 'notifikasi') {
      if (LN()) await LN().requestPermissions(); else if ('Notification' in window) await Notification.requestPermission();
    }
  } catch (e) { /* ditolak / tidak tersedia: status dibaca ulang di bawah */ }
  return queryPerm(kind);
}

let swReg = null;
export async function initServiceWorker() {
  if (!('serviceWorker' in navigator) || location.protocol === 'file:') return null;
  try { swReg = await navigator.serviceWorker.register('sw.js'); await navigator.serviceWorker.ready; } catch (e) { swReg = null; }
  return swReg;
}

const hash = s => { let h = 0; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return Math.abs(h) % 2000000000; };

// Tampilkan notifikasi sistem sekarang. Mengembalikan true bila benar-benar dikirim ke sistem.
export async function showOs({ id, title, body }) {
  if ((await queryPerm('notifikasi')) !== 'granted') return false;
  try {
    if (LN()) { await LN().schedule({ notifications: [{ id: hash('now' + id), title, body, schedule: { at: new Date(Date.now() + 400), allowWhileIdle: true } }] }); return true; }
    if (swReg && swReg.showNotification) { await swReg.showNotification(title, { body, tag: String(id), icon: 'icon.svg', badge: 'icon.svg' }); return true; }
    if ('Notification' in window) { new Notification(title, { body, tag: String(id) }); return true; }
  } catch (e) { /* abaikan: notifikasi di dalam aplikasi tetap ada */ }
  return false;
}

// Jadwalkan ulang notifikasi mendatang di sistem (hanya APK). items: [{id, title, body, atReal(ms epoch)}]
let lastSig = '';
export async function syncNative(items) {
  const ln = LN(); if (!ln) return false;
  const sig = items.map(i => i.id + ':' + Math.round(i.atReal / 1000)).join('|');
  if (sig === lastSig) return true; lastSig = sig;
  try {
    if ((await ln.checkPermissions()).display !== 'granted') return false;
    const pend = await ln.getPending(); if (pend && pend.notifications && pend.notifications.length) await ln.cancel({ notifications: pend.notifications.map(n => ({ id: n.id })) });
    const ok = items.filter(i => i.atReal > Date.now() + 1000).slice(0, 60);
    if (ok.length) await ln.schedule({ notifications: ok.map(i => ({ id: hash(i.id), title: i.title, body: i.body, schedule: { at: new Date(i.atReal), allowWhileIdle: true } })) });
    return true;
  } catch (e) { return false; }
}
export const nativeAvailable = () => !!LN();
export async function listShown() { try { return swReg && swReg.getNotifications ? await swReg.getNotifications() : []; } catch (e) { return []; } }
