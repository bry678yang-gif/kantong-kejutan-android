import { STATUS, TIPE, activeListings, buyerView, createListing, placeOrder, verifyCode, expireOrders, computeImpact, todayAt } from './logic.js';
import { load, save, reset, loadUi, saveUi } from './store.js';

const app = document.getElementById('app');
const HOUR = 3600000;
const loaded = load(Date.now());
let state = loaded.state;
let corrupt = loaded.status === 'corrupt';
let noStorage = loaded.status === 'nostorage';
let ui = loadUi();
let view = ui.role === 'toko' ? { name: 'tdash' } : ui.role === 'pembeli' ? { name: 'home' } : { name: 'role' };
let flash = null;
let draft = null;

const now = () => Date.now() + state.meta.offsetMs;
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const rp = n => 'Rp' + Number(n).toLocaleString('id-ID');
const p2 = n => String(n).padStart(2, '0');
const jam = ms => { const d = new Date(ms); return p2(d.getHours()) + ':' + p2(d.getMinutes()); };
const range = (a, b) => `${jam(a)}–${jam(b)}`;
const storeOf = id => state.stores.find(s => s.id === id);
const badgeCls = st => st === STATUS.DIPESAN ? 'o' : st === STATUS.HANGUS ? 'r' : '';

let toastTimer;
function toast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg; t.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('show'), 2600);
}

function go(name, params = {}) { view = { name, ...params }; flash = null; render(); window.scrollTo(0, 0); }

function flashHtml() {
  if (!flash) return '';
  return `<div class="${flash.ok ? 'okbox' : 'err'}">${flash.html ?? esc(flash.msg)}</div>`;
}

const TERMS = 'Hanya produk sisa hari yang sama dan belum kedaluwarsa yang boleh dijual. Produk harus diambil pada Jendela Ambil. (Kejelasan aturan hukum pangan masih menunggu konsultasi.)';

function toolsHtml() {
  return `<div class="tools"><div class="mu">Alat demo · jam simulasi ${jam(now())}${state.meta.offsetMs ? ' (dimajukan)' : ''}</div>
  <div class="row" style="margin-top:8px;gap:8px"><button class="btn sec sm" data-act="advance">Majukan jam 1 jam</button><button class="btn sec sm" data-act="reset">Reset demo</button></div></div>`;
}

function layout(body, navKey) {
  const nav = ui.role === 'pembeli' ? [['home', 'Beranda'], ['orders', 'Pesanan'], ['impact', 'Dampak']]
    : ui.role === 'toko' ? [['tdash', 'Dashboard'], ['tcreate', 'Buat listing'], ['impact', 'Dampak']] : [];
  return `<div class="demo">MODE DEMO · data dan pembayaran adalah simulasi${noStorage ? ' · penyimpanan perangkat tidak tersedia' : ''}</div>
  <header class="top"><h1>Kantong Kejutan</h1>${ui.role ? `<button data-act="roles">Ganti peran</button>` : ''}</header>
  <main>${body}${toolsHtml()}</main>
  ${nav.length ? `<nav class="bottom">${nav.map(([k, l]) => `<button class="${k === navKey ? 'on' : ''}" data-act="nav" data-to="${k}">${l}</button>`).join('')}</nav>` : ''}`;
}

const V = {};

V.corrupt = () => `<main class="screen"><p class="eyebrow">KANTONG KEJUTAN / MODE DEMO</p><h1>Data lokal tidak terbaca</h1><p class="muted">Reset demo untuk memuat ulang data contoh.</p><button class="btn" data-act="reset" data-force="1">Reset demo</button></main>`;

const bagArt = `<div class="bag-art"><div class="bag-handle"></div><div class="bag-body"><span>●</span></div></div>`;
const topLine = (title, back='home') => `<div class="screen-head"><button class="back" data-act="nav" data-to="${back}">‹</button><b>${title}</b><span></span></div>`;
const buyerNav = key => `<nav class="bottom fig-nav"><button class="${key==='home'?'on':''}" data-act="nav" data-to="home"><i>⌂</i>Beranda</button><button class="${key==='orders'?'on':''}" data-act="nav" data-to="orders"><i>▤</i>Pesanan</button><button class="${key==='impact'?'on':''}" data-act="nav" data-to="impact"><i>♡</i>Profil</button></nav>`;
const shopNav = key => `<nav class="bottom fig-nav"><button class="${key==='tdash'?'on':''}" data-act="nav" data-to="tdash"><i>⌂</i>Ringkasan</button><button class="${key==='tcreate'?'on':''}" data-act="nav" data-to="tcreate"><i>▣</i>Listing</button><button class="${key==='torders'?'on':''}" data-act="nav" data-to="torders"><i>▤</i>Pesanan</button></nav>`;
function screen(body, nav='buyer', key='home') { return `<div class="demo-ribbon">KANTONG KEJUTAN <span>•</span> MODE DEMO</div><main class="screen">${body}</main>${nav==='buyer'?buyerNav(key):nav==='shop'?shopNav(key):''}`; }

V.role = () => screen(`<p class="eyebrow">KANTONG KEJUTAN / SURABAYA</p><p class="welcome">Selamat datang di</p><h1>Kantong Kejutan</h1><p class="muted">Makanan baik, jangan sampai terbuang.</p><section class="hero-art">${bagArt}<b>Selamatkan makanan hari ini.</b><small>Temukan paket kejutan dari toko sekitar.</small></section><p class="section-label">Lanjutkan sebagai</p><button class="role-card" data-act="pickRole" data-role="pembeli"><span class="role-icon">☺</span><span><b>Pembeli</b><small>Cari dan ambil makanan favoritmu</small></span><strong>→</strong></button><div class="role-card" role="group"><span class="role-icon peach">⌂</span><span><b>Toko</b><small>Jual stok berlebih di akhir hari</small><label for="storeSel" class="visually-hidden">Pilih toko demo</label><select id="storeSel" class="store-select">${state.stores.map(s=>`<option value="${s.id}" ${s.id===ui.storeId?'selected':''}>${esc(s.nama)}</option>`).join('')}</select></span><button class="arrow-hit" data-act="pickRole" data-role="toko">→</button></div><p class="tiny-center">MODE DEMO • DATA TERSIMPAN DI PERANGKAT</p>`, 'none');

V.home = () => {
 const list=activeListings(state,now());
 const cards=list.map(l=>`<article class="listing-card" data-act="detail" data-id="${esc(l.id)}"><div class="listing-thumb">${bagArt}</div><div class="listing-info"><b>${esc(l.judul)}</b><small>${esc(l.tokoNama)} • ${l.jarakKm.toLocaleString('id-ID')} km</small><strong>${rp(l.harga)}</strong><small>${l.stok} ${l.tipe===TIPE.KEJUTAN?'kantong':'item'} tersisa</small><small>Ambil ${range(l.ambilStart,l.ambilEnd)}</small></div><span class="pill-action">Lihat</span></article>`).join('');
 return screen(`<div class="home-greeting"><div><small>Halo, selamat sore 👋</small><h1>Ada kejutan baik<br>di dekatmu.</h1><span class="location-pill">⌖ Surabaya, Indonesia</span></div><span class="avatar">☺</span></div><div class="search-box">⌕ <input id="searchListing" placeholder="Cari toko atau makanan" aria-label="Cari toko atau makanan"></div><div class="section-row"><h2>Temukan hari ini</h2><span class="sort-label">Urut: terdekat</span></div>${cards||'<div class="empty-card">Belum ada listing aktif. Coba majukan jam demo.</div>'}`, 'buyer','home');
};

V.detail = () => {
 const l=state.listings.find(x=>x.id===view.id), act=activeListings(state,now()).find(x=>x.id===view.id);
 if(!l||!act) return screen(`${topLine('Detail paket')}<h2>Listing tidak tersedia</h2><button class="btn" data-act="nav" data-to="home">Kembali</button>`,'buyer','home');
 const n=view.n??1, kejutan=act.tipe===TIPE.KEJUTAN;
 return screen(`${topLine('Detail paket')}<div class="detail-hero">${bagArt}<span class="tag">PAKET KEJUTAN</span></div><h1 class="detail-title">${esc(act.judul)}</h1><p class="muted">${esc(act.tokoNama)} • ${esc(act.area)} • ${act.jarakKm.toLocaleString('id-ID')} km dari kamu</p><div class="detail-price">${rp(act.harga)} <small>per ${kejutan?'kantong':'item'}</small></div><h3>Yang perlu kamu tahu</h3><ul class="feature-list"><li>Isi ${kejutan?'kantong dirahasiakan sampai diambil':'produk sesuai nama listing'}.</li><li>Produk merupakan sisa hari ini yang masih layak.</li><li>Ambil hari ini, pukul ${range(act.ambilStart,act.ambilEnd)}.</li></ul><div class="stock-box"><b>${act.stok} ${kejutan?'kantong':'item'} tersedia</b><small>Stok dapat berubah selama demo berlangsung</small></div><label for="qty">Jumlah</label><input class="field" id="qty" type="number" min="1" max="${act.stok}" value="${n}" data-price="${act.harga}"><div class="total-row"><span>Total</span><b id="totalTxt">${rp(act.harga*n)}</b></div>${flashHtml()}<button class="btn sticky-cta" data-act="toConfirm" data-id="${esc(act.id)}">Lanjut pesan</button>`, 'buyer','home');
};

V.confirm = () => { const l=state.listings.find(x=>x.id===view.id); if(!l)return V.detail(); const label=l.type===TIPE.KEJUTAN?'Paket Kejutan':l.nama; return screen(`${topLine('Konfirmasi pesanan','detail')}<h2>Pesanan kamu</h2><div class="order-product"><div class="mini-bag">${bagArt}</div><div><b>${esc(label)}</b><small>${esc(storeOf(l.storeId).nama)}</small><strong>${rp(l.harga)} / ${l.type===TIPE.KEJUTAN?'kantong':'item'}</strong></div></div><label>Jumlah ${l.type===TIPE.KEJUTAN?'kantong':'item'}</label><div class="quantity"><button data-act="qtyMinus">−</button><b>${view.n}</b><button data-act="qtyPlus">＋</button></div><h3>Rincian pembayaran</h3><div class="total-row"><span>Harga paket</span><b>${rp(l.harga*view.n)}</b></div><div class="total-row grand"><span>Total</span><b>${rp(l.harga*view.n)}</b></div><div class="notice">ⓘ Pembayaran ini hanya simulasi demo.<small>Tidak ada uang yang benar-benar ditagihkan.</small></div>${flashHtml()}<button class="btn sticky-cta" data-act="pay" data-id="${esc(l.id)}" data-n="${view.n}">Konfirmasi pembayaran demo</button>`, 'buyer','home'); };

V.order = () => { const o=state.orders.find(x=>x.id===view.id); if(!o)return V.orders(); return screen(`${topLine('Pesanan berhasil')}<div class="success-pill">PESANAN DIBUAT</div><h1 class="center-title">Tunjukkan kode ini<br>kepada kasir saat mengambil pesanan.</h1><div class="pickup-code">${esc(o.code)}<small>KODE AMBIL</small></div><div class="pickup-card"><b>${esc(o.judul)}</b><small>${esc(storeOf(o.storeId).nama)} • Surabaya</small><hr><div class="total-row"><span>Waktu pengambilan</span><b>Hari ini, ${range(o.ambilStart,o.ambilEnd)}</b></div><div class="total-row"><span>Status pesanan</span><b class="status-text">${o.status}</b></div></div><div class="notice">Pembayaran: simulasi demo<br><small>Simpan kode ini sampai pesanan diambil.</small></div><button class="btn sticky-cta" data-act="nav" data-to="home">Kembali ke beranda</button>`, 'buyer','orders'); };

V.orders = () => { const list=[...state.orders].reverse().map(o=>`<article class="merchant-order" data-act="openOrder" data-id="${esc(o.id)}"><div class="row"><b>${esc(o.code)}</b><span class="status-chip ${badgeCls(o.status)}">${o.status}</span></div><b>${esc(o.judul)} • ${o.qty} item</b><small>${esc(storeOf(o.storeId).nama)} • ${rp(o.total)}</small></article>`).join(''); return screen(`<h1>Pesanan saya</h1><p class="muted">Pantau kode dan status pengambilanmu.</p>${list||'<div class="empty-card">Belum ada pesanan.</div>'}`, 'buyer','orders'); };

V.impact = () => { const i=computeImpact(state); return screen(`<h1>Dampak hari ini</h1><h3>Setiap kantong yang terselamatkan</h3><p class="muted">adalah langkah kecil mengurangi sampah.</p><div class="impact-hero"><b>${i.unit}</b><span>kantong / porsi diambil</span><small>Berdasarkan pesanan berstatus Diambil</small></div><div class="impact-grid"><div><b>${rp(i.rupiah)}</b><small>Nilai transaksi</small></div><div><b>${i.co2Kg.toLocaleString('id-ID')} kg</b><small>Estimasi CO₂ terselamatkan</small></div></div><div class="notice warm"><b>Catatan perhitungan</b><small>Angka dampak adalah estimasi demo, bukan pengukuran emisi aktual.</small></div>`, 'buyer','impact'); };

V.tdash = () => { const st=storeOf(ui.storeId)||state.stores[0], orders=[...state.orders].filter(o=>o.storeId===st.id).reverse(); const stock=state.listings.filter(l=>l.storeId===st.id).reduce((n,l)=>n+l.stok,0); return screen(`<div class="shop-kicker">TOKO / MODE DEMO</div><p class="muted">Selamat sore,</p><h1>${esc(st.nama)}</h1><span class="active-store">TOKO AKTIF</span><h2>Ringkasan hari ini</h2><div class="stats-grid"><div><b>${stock}</b><small>Stok tayang</small></div><div><b>${orders.length}</b><small>Pesanan masuk</small></div></div><h2>Aksi cepat</h2><button class="quick-action" data-act="nav" data-to="tcreate">＋ <span><b>Buat listing baru</b><small>Tawarkan stok berlebih hari ini</small></span></button><div class="section-row"><h2>Pesanan terbaru</h2><button class="text-action" data-act="nav" data-to="torders">Lihat semua</button></div>${orders.slice(0,3).map(o=>`<article class="merchant-order" data-act="openOrder" data-id="${esc(o.id)}"><div class="row"><b>${esc(o.code)}</b><span class="status-chip ${badgeCls(o.status)}">${o.status}</span></div><small>${esc(o.judul)} • ${o.qty} item</small></article>`).join('')||'<div class="empty-card">Belum ada pesanan masuk.</div>'}`, 'shop','tdash'); };

V.tcreate = () => { const d=draft||(draft=newDraft()), item=d.type===TIPE.ITEM; return screen(`${topLine('Buat listing','tdash')}<h3>Apa yang ingin kamu tawarkan?</h3><div class="type-picker"><button class="${!item?'selected':''}" data-act="setType" data-type="kejutan">${bagArt}<b>Paket Kejutan</b><small>Isi dirahasiakan</small></button><button class="${item?'selected':''}" data-act="setType" data-type="item"><span class="item-illustration">◉</span><b>Item Pilihan</b><small>Produk spesifik</small></button></div>${item?`<label for="f_nama">Nama produk</label><input class="field" id="f_nama" value="${esc(d.nama)}" placeholder="Donat gula" maxlength="60">`:''}<label for="f_jumlah">Jumlah ${item?'item':'kantong'}</label><input class="field" id="f_jumlah" type="number" min="1" value="${esc(d.jumlah)}"><label for="f_harga">Harga per ${item?'item':'kantong'}</label><input class="field" id="f_harga" type="number" min="1" value="${esc(d.harga)}"><label>Jendela ambil</label><div class="time-fields"><input class="field" id="f_start" type="time" value="${esc(d.start)}"><span>sampai</span><input class="field" id="f_end" type="time" value="${esc(d.end)}"></div>${!item?'<div class="notice green">Tidak perlu menuliskan isi kantong.<small>Pembeli mengetahui isi saat pengambilan.</small></div>':''}${flashHtml()}<button class="btn sticky-cta" data-act="saveListing">Terbitkan listing</button>`, 'shop','tcreate'); };

V.verify = () => screen(`${topLine('Verifikasi pengambilan','tdash')}<h1>Verifikasi pengambilan</h1><p class="muted">Masukkan kode dari pembeli</p><p class="muted small">Pastikan kode belum pernah digunakan.</p><input class="field code-field" id="kode" autocapitalize="characters" autocomplete="off" maxlength="12" placeholder="KJ-4821">${flashHtml()}<button class="btn" data-act="verify">Verifikasi kode</button><div class="notice green">✓<b>Pesanan ditemukan</b><small>Setelah diverifikasi, status berubah menjadi Diambil dan kode tidak dapat dipakai lagi.</small></div><span class="success-pill">DIAMBIL</span>`, 'shop','torders');

V.torders = () => { const orders=[...state.orders].filter(o=>o.storeId===ui.storeId).reverse(); return screen(`<h1>Pesanan masuk</h1><p class="muted">Pantau status dan proses pengambilan.</p><div class="filter-tabs"><button class="on">Semua</button><button>Dipesan</button><button>Diambil</button></div>${orders.map(o=>`<article class="merchant-order" data-act="openOrder" data-id="${esc(o.id)}"><div class="row"><b>${esc(o.code)}</b><span class="status-chip ${badgeCls(o.status)}">${o.status}</span></div><b>${esc(o.judul)} • ${o.qty} item</b><small>Hari ini • ${range(o.ambilStart,o.ambilEnd)}</small><button class="text-action" data-act="goVerify">Verifikasi kode →</button></article>`).join('')||'<div class="empty-card">Belum ada pesanan masuk.</div>'}<div class="notice warm"><b>Tips pengambilan</b><small>Cocokkan kode sebelum menyerahkan pesanan.</small></div>`, 'shop','torders'); };

function render() {
  try {
    if (corrupt) { app.innerHTML = V.corrupt(); return; }
    if (expireOrders(state, now()) > 0) save(state);
    app.innerHTML = (V[view.name] || V.role)();
  } catch (e) { fatal(e); }
}

function fatal(e) {
  console.error(e);
  app.innerHTML = `<div class="demo">MODE DEMO</div><main><h2>Terjadi kendala</h2><p>Aplikasi tetap aman. Anda bisa kembali ke beranda atau mereset data demo.</p>
  <button class="btn" data-act="home">Kembali ke beranda</button><button class="btn sec" data-act="reset">Reset demo</button></main>`;
}

function hhmm(ms) { const d = new Date(ms), t = new Date(now()); return d.getDate() !== t.getDate() ? '23:59' : jam(ms); }
function newDraft() { return { type: TIPE.KEJUTAN, nama: '', jumlah: '5', harga: '15000', start: hhmm(now() + 0.5 * HOUR), end: hhmm(now() + 3 * HOUR) }; }

const A = {
  roles() { ui.role = null; saveUi(ui); go('role'); },
  home() { go(ui.role === 'toko' ? 'tdash' : ui.role === 'pembeli' ? 'home' : 'role'); },
  pickRole(el) {
    const sel = document.getElementById('storeSel');
    ui = { role: el.dataset.role, storeId: sel ? sel.value : ui.storeId };
    saveUi(ui); go(ui.role === 'toko' ? 'tdash' : 'home');
  },
  nav(el) { if (el.dataset.to === 'tcreate') draft = newDraft(); go(el.dataset.to); },
  goVerify() { go('verify'); },
  qtyMinus() { view.n=Math.max(1,(view.n||1)-1); render(); },
  qtyPlus() { const l=state.listings.find(x=>x.id===view.id); view.n=Math.min(l?.stok||1,(view.n||1)+1); render(); },
  detail(el) { go('detail', { id: el.dataset.id, n: 1 }); },
  toConfirm(el) {
    const l = state.listings.find(x => x.id === el.dataset.id);
    const n = Number(document.getElementById('qty').value);
    let msg = null;
    if (!Number.isInteger(n) || n < 1) msg = 'Jumlah minimal 1 dan harus bilangan bulat.';
    else if (l && n > l.stok) msg = `Stok tersedia hanya ${l.stok}.`;
    if (msg) { view = { name: 'detail', id: el.dataset.id, n: Number.isFinite(n) ? n : 1 }; flash = { ok: false, msg }; render(); return; }
    go('confirm', { id: el.dataset.id, n });
  },
  pay(el) {
    const r = placeOrder(state, el.dataset.id, Number(el.dataset.n), now());
    if (!r.ok) { toast(r.error); go('home'); return; }
    save(state); go('order', { id: r.order.id });
  },
  openOrder(el) { go('order', { id: el.dataset.id }); },
  setType(el) { draft.type = el.dataset.type; flash = null; render(); },
  saveListing() {
    const t = now();
    const input = { type: draft.type, nama: draft.nama, jumlah: Number(draft.jumlah), harga: Number(draft.harga),
      ambilStart: todayAt(draft.start, t), ambilEnd: todayAt(draft.end, t) };
    const r = createListing(state, ui.storeId, input, t);
    if (!r.ok) { flash = { ok: false, html: r.errors.map(esc).join('<br>') }; render(); return; }
    save(state); toast('Listing dibuat dan tampil untuk Pembeli.'); go('tdash');
  },
  verify() {
    const r = verifyCode(state, ui.storeId, document.getElementById('kode').value, now());
    save(state);
    flash = r.ok ? { ok: true, msg: `Berhasil: ${r.order.judul} × ${r.order.qty} (${rp(r.order.total)}) ditandai Diambil.` } : { ok: false, msg: r.error };
    render();
  },
  advance() { state.meta.offsetMs += HOUR; save(state); render(); toast('Jam simulasi maju 1 jam.'); },
  reset(el) {
    if (!el.dataset.force && !window.confirm('Reset demo? Semua pesanan dan listing baru akan dihapus.')) return;
    state = reset(Date.now()); corrupt = false; noStorage = false; ui = { role: null, storeId: 's1' };
    view = { name: 'role' }; flash = null; render(); toast('Demo dikembalikan ke kondisi awal.');
  },
};

app.addEventListener('click', e => {
  const el = e.target.closest('[data-act]');
  if (!el || !A[el.dataset.act]) return;
  try { A[el.dataset.act](el); } catch (err) { fatal(err); }
});

app.addEventListener('input', e => {
  const t = e.target;
  if (t.id === 'qty') {
    const n = Number(t.value), price = Number(t.dataset.price), out = document.getElementById('totalTxt');
    if (out) out.textContent = Number.isInteger(n) && n > 0 ? rp(price * n) : '–';
  } else if (t.id && t.id.startsWith('f_') && draft) {
    draft[t.id.slice(2)] = t.value;
  }
});

window.addEventListener('error', e => fatal(e.error || e.message));
window.addEventListener('unhandledrejection', e => fatal(e.reason));
render();
