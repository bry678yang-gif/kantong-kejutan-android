import { STATUS, TIPE, activeListings, createListing, placeOrder, verifyCode, expireOrders, computeImpact, todayAt } from './logic.js';
import { load, save, reset, loadUi, saveUi } from './store.js';
import { art, kindFor, STORE_ART, icon } from './art.js';

const app = document.getElementById('app');
const HOUR = 3600000;
const loaded = load(Date.now());
let state = loaded.state;
let corrupt = loaded.status === 'corrupt';
let noStorage = loaded.status === 'nostorage';
let ui = loadUi();
let view = ui.role === 'toko' ? { name: 'tdash' } : ui.role === 'pembeli' ? { name: 'home' } : { name: 'role' };
let flash = null, draft = null, menuOpen = false, sheet = null;
let q = '', qd = '', ftipe = 'semua', sortBy = 'jarak', storeFilter = null, selId = null, dashIdx = 0;
const qty = {};

const now = () => Date.now() + state.meta.offsetMs;
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const rp = n => 'Rp' + Number(n).toLocaleString('id-ID');
const p2 = n => String(n).padStart(2, '0');
const jam = ms => { const d = new Date(ms); return p2(d.getHours()) + ':' + p2(d.getMinutes()); };
const range = (a, b) => `${jam(a)}–${jam(b)}`;
const km = n => n.toLocaleString('id-ID') + ' km';
const storeOf = id => state.stores.find(s => s.id === id);
const badgeCls = st => st === STATUS.DIPESAN ? 'o' : st === STATUS.HANGUS ? 'r' : '';
const thumb = (kind, extra = '') => `<div class="thumb ${extra}">${art(kind)}</div>`;
const kOf = x => kindFor(x.tipe || x.type, x.judul);
const TERMS = 'Hanya produk sisa hari yang sama dan belum kedaluwarsa yang boleh dijual. Produk harus diambil pada Jendela Ambil. (Kejelasan aturan hukum pangan masih menunggu konsultasi.)';
const DISC = 'Nama merek, produk, harga, dan jarak di sini hanya ilustrasi untuk demo lomba; belum ada kerja sama dengan merek tersebut.';
const ago = ms => { const m = Math.max(0, Math.round((now() - ms) / 60000)); return m < 60 ? `${m} mnt lalu` : `${Math.floor(m / 60)} jam lalu`; };

let toastTimer;
function toast(msg) { const t = document.getElementById('toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('show'), 2600); }
function go(name, params = {}) { view = { name, ...params }; flash = null; menuOpen = false; sheet = null; render(); window.scrollTo(0, 0); }
function flashHtml() { return flash ? `<div class="${flash.ok ? 'okbox' : 'err'}">${flash.html ?? esc(flash.msg)}</div>` : ''; }

const header = (right = '<span class="dp">DEMO</span>') => `<header class="top"><button class="ib" data-act="menu" aria-label="Menu">${icon('menu')}<i class="dot"></i></button><div class="logo">kantong<i>kejutan</i></div>${right}</header>`;

function overlays() {
  let h = '';
  if (menuOpen) h += `<div class="ov t" data-act="menuClose"><div class="mn" data-stop="1"><div class="mm">MODE DEMO · jam simulasi ${jam(now())}${state.meta.offsetMs ? ' (dimajukan)' : ''}${noStorage ? ' · penyimpanan perangkat tidak tersedia' : ''}</div>
    <button class="mi" data-act="roles">Ganti peran</button><button class="mi" data-act="advance">Majukan jam 1 jam</button><button class="mi" data-act="reset">Reset demo</button></div></div>`;
  if (sheet === 'verify') h += `<div class="ov b" data-act="sheetClose"><div class="sh" data-stop="1"><h3>Verifikasi Kode Ambil</h3><label class="lab" for="kode">Kode dari pembeli</label>
    <input class="in" id="kode" autocapitalize="characters" autocomplete="off" maxlength="12" placeholder="mis. K7H2PQ">${flashHtml()}
    <button class="bt f w" style="width:100%;margin:1.2rem 0 0" data-act="verify">Verifikasi</button></div></div>`.replace('12u', '1.2rem');
  return h;
}

function page(body, navKey) {
  const nav = ui.role === 'pembeli' ? [['home', 'Beranda', 'home'], ['stores', 'Toko', 'store'], ['orders', 'Pesanan', 'list'], ['impact', 'Dampak', 'leaf']]
    : ui.role === 'toko' ? [['tdash', 'Pesanan', 'list'], ['tcreate', 'Buat', 'plus'], ['impact', 'Dampak', 'leaf']] : [];
  return `<div class="pg">${body}</div>${nav.length ? `<nav class="nav">${nav.map(([k, l, i]) => `<button class="nv ${k === navKey ? 'on' : ''}" data-act="nav" data-to="${k}">${icon(i)}${l}</button>`).join('')}</nav>` : ''}${overlays()}`;
}

const V = {};
V.corrupt = () => `<header class="top"><div class="logo">kantong<i>kejutan</i></div><span class="dp">DEMO</span></header><h2 class="tt">Data lokal rusak</h2><p class="hp">Data di perangkat tidak bisa dibaca. Reset demo akan memuat ulang data contoh.</p><button class="bt f w" data-act="reset" data-force="1">Reset demo</button>`;

V.role = () => page(`${header()}
  <div class="hw">${thumb('bag')}<span class="bd l">${icon('pin')}</span><span class="bd r">${icon('bag')}</span></div>
  <h1 class="hd">Selamatkan yang <em>manis</em> sebelum tutup!</h1>
  <p class="hp">Pilih peran untuk memulai demo, tanpa login. Data dan pembayaran di aplikasi ini adalah simulasi.</p>
  <div class="card" style="margin-top:20px"><b>Saya Pembeli</b><p class="mu">Cari paket dan item sisa dengan harga miring, lalu ambil di toko.</p><button class="bt f w" style="margin:0;width:100%" data-act="pickRole" data-role="pembeli">Masuk sebagai Pembeli</button></div>
  <div class="card"><b>Saya Toko</b><p class="mu">Unggah sisa produk menjelang tutup dan verifikasi Kode Ambil.</p>
  <label class="lab" for="storeSel">Pilih toko demo</label><select class="in" id="storeSel">${state.stores.map(s => `<option value="${s.id}" ${s.id === ui.storeId ? 'selected' : ''}>${esc(s.nama)}</option>`).join('')}</select>
  <button class="bt o w" style="margin:12px 0 0;width:100%" data-act="pickRole" data-role="toko">Masuk sebagai Toko</button></div>`, null);

function filtered() {
  let list = activeListings(state, now()).filter(l => ftipe === 'semua' || l.tipe === ftipe);
  const t = q.trim().toLowerCase();
  if (t) list = list.filter(l => (l.judul + ' ' + l.tokoNama).toLowerCase().includes(t));
  if (sortBy === 'harga') list.sort((a, b) => a.harga - b.harga);
  return list;
}
const curQ = l => Math.min(Math.max(qty[l.id] || 1, 1), l.stok);

V.home = () => {
  const list = filtered();
  const rows = list.map(l => `<div class="row" data-act="detail" data-id="${esc(l.id)}">${thumb(kOf(l))}
    <div><b>${esc(l.judul)}</b><small>${esc(l.tokoNama)} · ${km(l.jarakKm)}</small><div class="pr"><span class="p">${rp(l.harga)}</span><button class="pill" data-act="quick" data-id="${esc(l.id)}">Pesan</button></div></div>
    <div class="stp"><button data-act="qup" data-id="${esc(l.id)}" aria-label="Tambah">${icon('up')}</button><span>${curQ(l)}</span><button data-act="qdn" data-id="${esc(l.id)}" aria-label="Kurangi">${icon('down')}</button></div></div>`).join('');
  const chip = (k, l) => `<button class="chip ${ftipe === k ? 'on' : ''}" data-act="ftipe" data-k="${k}">${l}</button>`;
  return page(`<header class="top"><button class="ib" data-act="menu" aria-label="Menu">${icon('menu')}<i class="dot"></i></button>
    <div class="user"><div><b>Pembeli Demo</b><small>Surabaya · MODE DEMO</small></div><div class="av">PD</div></div></header>
  <div class="search">${icon('search')}<input id="q" placeholder="Cari roti atau toko" value="${esc(q)}" autocomplete="off"><button class="ib" data-act="sort" aria-label="Urutkan">${icon('sliders')}</button></div>
  <div class="hw">${thumb('bag')}<span class="bd l">${icon('pin')}</span><span class="bd r">${icon('bag')}</span></div>
  <h1 class="hd">Selamatkan yang <em>manis</em> sebelum tutup!</h1>
  <p class="hp">Roti dan donat sisa hari ini dari toko di Surabaya, dengan harga miring. Data dan pembayaran adalah demo.</p>
  <button class="pill m" data-act="scrollList">Lihat daftar</button>
  <div class="chips">${chip('semua', 'Semua')}${chip('kejutan', 'Paket Kejutan')}${chip('item', 'Item Pilihan')}</div>
  <div class="lh" id="list"><h2>${list.length} Listing</h2><button class="sort" data-act="sort">${sortBy === 'harga' ? 'Termurah' : 'Terdekat'} ${icon('down')}</button></div>
  ${rows || '<div class="card mu">Belum ada listing yang cocok. Coba ubah pencarian atau Majukan jam / Reset demo.</div>'}<p class="disc">${esc(DISC)}</p>`, 'home');
};

V.detail = () => {
  const act = activeListings(state, now()).find(x => x.id === view.id);
  if (!act) return page(`${header()}<h2 class="tt">Listing tidak tersedia</h2><p class="hp">Stok habis atau waktu jual sudah berakhir.</p><button class="bt f w" data-act="nav" data-to="home">Kembali ke daftar</button>`, 'home');
  const kej = act.tipe === TIPE.KEJUTAN, n = Math.min(Math.max(view.n || 1, 1), act.stok);
  const more = activeListings(state, now()).filter(x => x.id !== act.id).map(l => `<div class="it" data-act="detail" data-id="${esc(l.id)}">${thumb(kOf(l))}<div><b style="font-size:1.2rem">${esc(l.judul)}</b><small style="display:block;font-size:.7rem;color:var(--ol);font-weight:600">${esc(l.tokoNama)}</small>
    <div class="pr"><span class="p" style="font-size:1.25rem;font-weight:700">${rp(l.harga)}</span><button class="pill" data-act="detail" data-id="${esc(l.id)}">Lihat</button></div></div></div>`).join('');
  return page(`<div class="dh"><header class="top"><button class="ib" data-act="nav" data-to="home" aria-label="Kembali">${icon('back')}</button><span class="dp">DEMO</span></header><div class="big">${art(kOf(act))}</div></div>
  <div class="sheet"><div class="tr"><h1>${esc(act.judul)}</h1><span class="pp">${rp(act.harga)}</span></div>
  <div class="sub">${kej ? 'Paket Kejutan' : 'Item Pilihan'} · ${esc(act.tokoNama)}</div>
  <div class="buy"><div class="qty"><button data-act="ddn" aria-label="Kurangi">${icon('minus')}</button><span id="qv">${n}</span><button data-act="dup" aria-label="Tambah">${icon('plus')}</button></div><button class="pill m" style="margin:0" data-act="toConfirm" data-id="${esc(act.id)}">Pesan</button></div>
  <div class="tot">Total <b>${rp(act.harga * n)}</b> · pembayaran simulasi</div>${flashHtml()}
  <div class="meta"><span>${icon('bag')}Sisa ${act.stok}</span><span>${icon('pin')}${km(act.jarakKm)} · ${esc(act.area)}</span><span>${icon('list')}Ambil ${range(act.ambilStart, act.ambilEnd)}</span></div>
  <h3 class="sec">Deskripsi</h3><p class="desc">${kej ? 'Kantong berisi sisa roti dan donat hari ini. Isi kantong dirahasiakan sampai pengambilan.' : `${esc(act.judul)} sisa hari ini dari ${esc(act.tokoNama)}.`} ${esc(TERMS)} ${esc(DISC)}</p>
  <h3 class="sec">Coba juga<a>${more ? '' : ''}</a></h3><div class="also">${more || '<span class="mu">Belum ada listing lain.</span>'}</div></div>`, 'home');
};

V.confirm = () => {
  const l = state.listings.find(x => x.id === view.id);
  if (!l) return V.detail();
  const label = l.type === TIPE.KEJUTAN ? 'Paket Kejutan' : l.nama;
  return page(`${header()}<h2 class="tt">Konfirmasi pesanan</h2><div class="card"><div class="rowc"><b>${esc(label)} × ${view.n}</b><span class="pp">${rp(l.harga * view.n)}</span></div><div class="mu">${esc(storeOf(l.storeId).nama)}<br>Ambil ${range(l.ambilStart, l.ambilEnd)}</div></div>
  <div class="note"><b>Pembayaran SIMULASI.</b> Tidak ada uang sungguhan yang dipindahkan.</div>
  <button class="bt f w" data-act="pay" data-id="${esc(l.id)}" data-n="${view.n}">Bayar (simulasi)</button><button class="bt o w" data-act="detail" data-id="${esc(l.id)}">Ubah jumlah</button>`, 'home');
};

V.order = () => {
  const o = state.orders.find(x => x.id === view.id);
  if (!o) return V.orders();
  return page(`${header()}<h2 class="tt">Pesanan ${o.status === STATUS.DIPESAN ? 'berhasil' : o.status.toLowerCase()}</h2><div class="code">${esc(o.code)}</div>
  <p class="mu" style="text-align:center">Tunjukkan Kode Ambil ini ke toko.</p>
  <div class="card"><div class="rowc"><b>${esc(o.judul)} × ${o.qty}</b><span class="badge ${badgeCls(o.status)}">${o.status}</span></div><div class="mu">${esc(storeOf(o.storeId).nama)}<br>Ambil ${range(o.ambilStart, o.ambilEnd)}</div>
  <div class="rowc" style="margin-top:8px"><span class="mu">Total (pembayaran simulasi)</span><b>${rp(o.total)}</b></div></div>
  <div class="note">${esc(TERMS)} Pesanan yang tidak diambil sampai Jendela Ambil berakhir menjadi Hangus.</div>
  <button class="bt f w" data-act="nav" data-to="orders">Lihat semua pesanan</button><button class="bt o w" data-act="nav" data-to="home">Kembali ke daftar</button>`, 'orders');
};

V.orders = () => {
  const list = [...state.orders].reverse().map(o => `<div class="row" data-act="openOrder" data-id="${esc(o.id)}">${thumb(kindFor(o.type, o.judul))}<div><b>${esc(o.judul)} × ${o.qty}</b><small>${esc(storeOf(o.storeId).nama)} · Kode ${esc(o.code)}</small><div class="pr"><span class="p">${rp(o.total)}</span></div></div><span class="badge ${badgeCls(o.status)}">${o.status}</span></div>`).join('');
  return page(`${header()}<h2 class="tt">Pesanan saya</h2>${list || '<div class="card mu">Belum ada pesanan.</div>'}`, 'orders');
};

V.impact = () => {
  const i = computeImpact(state);
  return page(`${header()}<h2 class="tt">Dampak SDG 12</h2><p class="mu" style="margin:-6px 21px 12px">Dihitung hanya dari pesanan berstatus Diambil (${i.orders} pesanan).</p>
  <div class="grid"><div class="card"><div class="big">${i.unit}</div><div class="mu">kantong/porsi terselamatkan</div></div><div class="card"><div class="big" style="font-size:2.2rem">${rp(i.rupiah)}</div><div class="mu">nilai pesanan diambil</div></div></div>
  <div class="card" style="margin-top:10px"><div class="big">${i.co2Kg.toLocaleString('id-ID')} kg</div><div class="mu">estimasi CO₂e terhindar (estimasi)</div></div>
  <div class="note">Parameter: ${i.params.kgPerUnit} kg makanan per kantong × ${i.params.co2PerKg} kg CO₂e per kg. ${esc(i.sumber)}</div>`, 'impact');
};

V.stores = () => {
  const all = activeListings(state, now());
  const list = all.filter(l => !storeFilter || l.tokoId === storeFilter);
  const sel = list.some(l => l.id === selId) ? selId : (list[0] && list[0].id);
  const cats = state.stores.map(s => `<button class="cc ${storeFilter === s.id ? 'on' : ''}" data-act="storePick" data-id="${s.id}" aria-label="${esc(s.nama)}">${thumb(STORE_ART[s.id] || 'rolls')}</button>`).join('');
  const pills = list.map(l => `<div class="pl ${l.id === sel ? 'on' : ''}" data-act="pill" data-id="${esc(l.id)}">${thumb(kOf(l))}<div><b>${esc(l.judul)}</b><small>${esc(l.tokoNama)}</small><div class="ic2"><span style="display:flex;gap:3px;align-items:center">${icon('pin')}${km(l.jarakKm)}</span><span style="display:flex;gap:3px;align-items:center">${icon('bag')}Sisa ${l.stok}</span></div></div><span class="p">${rp(l.harga)}</span></div>`).join('');
  const nm = storeFilter ? storeOf(storeFilter).nama : 'Semua toko';
  return page(`${header()}<div class="cath"><h2 class="tt" style="margin:0">Kategori</h2><button data-act="storeAll">lihat semua</button></div>
  <div class="cat">${cats}</div><div class="cn"><span>${icon('left')}</span><span>${icon('right')}</span></div>
  <div class="cath" style="margin:0 0 10px"><b style="font-size:1.1rem">${esc(nm)}</b></div>${pills || '<div class="card mu">Belum ada listing aktif di toko ini.</div>'}`, 'stores');
};

V.tdash = () => {
  const st = storeOf(ui.storeId) || state.stores[0];
  const t = qd.trim().toLowerCase();
  const orders = [...state.orders].filter(o => o.storeId === st.id && (!t || (o.judul + ' ' + o.status).toLowerCase().includes(t))).reverse();
  const idx = orders.length ? ((dashIdx % orders.length) + orders.length) % orders.length : 0;
  const f = orders[idx];
  const next = orders.filter((_, i) => i !== idx).slice(0, 3).map(o => `<div class="nx">${thumb(kindFor(o.type, o.judul))}<div><b>${esc(o.judul)}</b><small>${o.status}</small></div><span class="ring">×${o.qty}</span></div>`).join('');
  const featHtml = f ? `<div class="feat"><div class="fc">${thumb(kindFor(f.type, f.judul))}</div><div class="fc fb">${thumb(kindFor(f.type, f.judul), 'x')}</div>
    <div class="ft"><b>${esc(f.judul)}</b><small style="display:block;font-size:.7rem;color:var(--ol);font-weight:600">${f.status} · ×${f.qty}</small><div class="pp">${rp(f.total)}</div><p>Ambil ${range(f.ambilStart, f.ambilEnd)}. Pembeli menunjukkan Kode Ambil, lalu Anda verifikasi.</p></div>
    <div class="arr"><button data-act="dprev" aria-label="Sebelumnya">${icon('left')}</button><button data-act="dnext" aria-label="Berikutnya">${icon('right')}</button></div></div>`
    : `<div class="feat"><div class="fc">${thumb('bag')}</div><div class="ft"><b>Belum ada pesanan</b><p>Pesanan dari pembeli akan muncul di sini.</p></div></div>`;
  const mine = state.listings.filter(l => l.storeId === st.id).map(l => `<div class="nx">${thumb(kindFor(l.type, l.nama))}<div><b>${esc(l.type === TIPE.KEJUTAN ? 'Paket Kejutan' : l.nama)}</b><small>Sisa ${l.stok} dari ${l.stokAwal} · ${rp(l.harga)}</small></div><span class="ring">${l.stok}</span></div>`).join('');
  return page(`${header()}<div class="search" style="margin-top:20px">${icon('search')}<input id="qd" placeholder="Cari pesanan" value="${esc(qd)}" autocomplete="off"></div>
  <div class="tr2"><h2 class="tt" style="margin:0">Pesanan masuk</h2><span class="ago">${f ? ago(f.createdAt) : esc(st.nama)}</span></div>${featHtml}
  <div class="nxh"><h3>Berikutnya</h3></div>${next || '<p class="mu" style="padding:0 21px">Tidak ada pesanan lain.</p>'}
  <div class="bb"><button class="bt f" data-act="sheet" data-s="verify">Verifikasi</button><button class="bt o" data-act="nav" data-to="tcreate">Baru</button></div>
  <div class="nxh" style="margin-top:22px"><h3>Listing ${esc(st.nama)}</h3></div>${mine || '<p class="mu" style="padding:0 21px">Belum ada listing.</p>'}`, 'tdash');
};

V.tcreate = () => {
  const d = draft || (draft = newDraft());
  const chip = (k, l) => `<button class="chip ${d.type === k ? 'on' : ''}" data-act="setType" data-type="${k}">${l}</button>`;
  return page(`${header()}<h2 class="tt">Buat listing</h2><div class="fm"><label class="lab">Jenis</label><div class="chips" style="padding:0;margin:0">${chip('kejutan', 'Paket Kejutan')}${chip('item', 'Item Pilihan')}</div>
  ${d.type === TIPE.ITEM ? `<label class="lab" for="f_nama">Nama produk</label><input class="in" id="f_nama" value="${esc(d.nama)}" maxlength="60">` : '<p class="mu" style="margin-top:10px">Isi kantong tidak perlu diisi dan tidak ditampilkan ke pembeli.</p>'}
  <label class="lab" for="f_jumlah">Jumlah ${d.type === TIPE.KEJUTAN ? 'kantong' : ''}</label><input class="in" id="f_jumlah" type="number" inputmode="numeric" min="1" value="${esc(d.jumlah)}">
  <label class="lab" for="f_harga">Harga satuan (Rp)</label><input class="in" id="f_harga" type="number" inputmode="numeric" min="1" value="${esc(d.harga)}">
  <div class="g2"><div><label class="lab" for="f_start">Ambil mulai</label><input class="in" id="f_start" type="time" value="${esc(d.start)}"></div><div><label class="lab" for="f_end">Ambil selesai</label><input class="in" id="f_end" type="time" value="${esc(d.end)}"></div></div></div>
  <div class="note">${esc(TERMS)}</div>${flashHtml()}<button class="bt f w" data-act="saveListing">Simpan listing</button>`, 'tcreate');
};

function render() {
  try {
    if (corrupt) { app.innerHTML = V.corrupt(); return; }
    if (expireOrders(state, now()) > 0) save(state);
    app.innerHTML = (V[view.name] || V.role)();
  } catch (e) { fatal(e); }
}
function fatal(e) {
  console.error(e);
  app.innerHTML = `<header class="top"><div class="logo">kantong<i>kejutan</i></div><span class="dp">DEMO</span></header><h2 class="tt">Terjadi kendala</h2><p class="hp">Aplikasi tetap aman. Anda bisa kembali ke beranda atau mereset data demo.</p>
  <button class="bt f w" data-act="home">Kembali ke beranda</button><button class="bt o w" data-act="reset">Reset demo</button>`;
}

function hhmm(ms) { const d = new Date(ms), t = new Date(now()); return d.getDate() !== t.getDate() ? '23:59' : jam(ms); }
function newDraft() { return { type: TIPE.KEJUTAN, nama: '', jumlah: '5', harga: '15000', start: hhmm(now() + 0.5 * HOUR), end: hhmm(now() + 3 * HOUR) }; }
const stokOf = id => { const l = state.listings.find(x => x.id === id); return l ? l.stok : 1; };

const A = {
  menu() { menuOpen = !menuOpen; render(); },
  menuClose() { menuOpen = false; render(); },
  sheetClose() { sheet = null; flash = null; render(); },
  sheet(el) { sheet = el.dataset.s; flash = null; render(); setTimeout(() => { const k = document.getElementById('kode'); if (k) k.focus(); }, 30); },
  roles() { ui.role = null; saveUi(ui); go('role'); },
  home() { go(ui.role === 'toko' ? 'tdash' : ui.role === 'pembeli' ? 'home' : 'role'); },
  pickRole(el) { const sel = document.getElementById('storeSel'); ui = { role: el.dataset.role, storeId: sel ? sel.value : ui.storeId }; saveUi(ui); go(ui.role === 'toko' ? 'tdash' : 'home'); },
  nav(el) { if (el.dataset.to === 'tcreate') draft = newDraft(); go(el.dataset.to); },
  detail(el) { go('detail', { id: el.dataset.id, n: 1 }); },
  ftipe(el) { ftipe = el.dataset.k; render(); },
  sort() { sortBy = sortBy === 'jarak' ? 'harga' : 'jarak'; render(); toast(sortBy === 'harga' ? 'Diurutkan: termurah' : 'Diurutkan: terdekat'); },
  scrollList() { const e = document.getElementById('list'); if (e) e.scrollIntoView({ behavior: 'smooth' }); },
  qup(el) { qty[el.dataset.id] = Math.min((qty[el.dataset.id] || 1) + 1, stokOf(el.dataset.id)); render(); },
  qdn(el) { qty[el.dataset.id] = Math.max((qty[el.dataset.id] || 1) - 1, 1); render(); },
  quick(el) { go('confirm', { id: el.dataset.id, n: Math.min(Math.max(qty[el.dataset.id] || 1, 1), stokOf(el.dataset.id)) }); },
  dup() { view.n = Math.min((view.n || 1) + 1, stokOf(view.id)); render(); },
  ddn() { view.n = Math.max((view.n || 1) - 1, 1); render(); },
  toConfirm(el) { go('confirm', { id: el.dataset.id, n: Math.min(Math.max(view.n || 1, 1), stokOf(el.dataset.id)) }); },
  pay(el) {
    const r = placeOrder(state, el.dataset.id, Number(el.dataset.n), now());
    if (!r.ok) { toast(r.error); go('home'); return; }
    save(state); go('order', { id: r.order.id });
  },
  openOrder(el) { go('order', { id: el.dataset.id }); },
  storePick(el) { storeFilter = storeFilter === el.dataset.id ? null : el.dataset.id; selId = null; render(); },
  storeAll() { storeFilter = null; selId = null; render(); },
  pill(el) { if (selId === el.dataset.id || (!selId && el.classList.contains('on'))) go('detail', { id: el.dataset.id, n: 1 }); else { selId = el.dataset.id; render(); } },
  dprev() { dashIdx--; render(); }, dnext() { dashIdx++; render(); },
  setType(el) { draft.type = el.dataset.type; flash = null; render(); },
  saveListing() {
    const t = now();
    const input = { type: draft.type, nama: draft.nama, jumlah: Number(draft.jumlah), harga: Number(draft.harga), ambilStart: todayAt(draft.start, t), ambilEnd: todayAt(draft.end, t) };
    const r = createListing(state, ui.storeId, input, t);
    if (!r.ok) { flash = { ok: false, html: r.errors.map(esc).join('<br>') }; render(); return; }
    save(state); toast('Listing dibuat dan tampil untuk Pembeli.'); go('tdash');
  },
  verify() {
    const r = verifyCode(state, ui.storeId, document.getElementById('kode').value, now());
    save(state);
    if (r.ok) { sheet = null; flash = null; render(); toast(`Berhasil: ${r.order.judul} × ${r.order.qty} (${rp(r.order.total)}) ditandai Diambil.`); }
    else { flash = { ok: false, msg: r.error }; render(); const k = document.getElementById('kode'); if (k) k.focus(); }
  },
  advance() { state.meta.offsetMs += HOUR; menuOpen = false; save(state); render(); toast('Jam simulasi maju 1 jam.'); },
  reset(el) {
    if (!el.dataset.force && !window.confirm('Reset demo? Semua pesanan dan listing baru akan dihapus.')) return;
    state = reset(Date.now()); corrupt = false; noStorage = false; ui = { role: null, storeId: 's1' };
    q = qd = ''; ftipe = 'semua'; sortBy = 'jarak'; storeFilter = null; selId = null; dashIdx = 0; menuOpen = false; sheet = null;
    view = { name: 'role' }; flash = null; render(); toast('Demo dikembalikan ke kondisi awal.');
  },
};

app.addEventListener('click', e => {
  const el = e.target.closest('[data-act]');
  if (!el || !A[el.dataset.act]) return;
  if (el.dataset.act === 'menuClose' || el.dataset.act === 'sheetClose') { if (e.target.closest('[data-stop]')) return; }
  try { A[el.dataset.act](el); } catch (err) { fatal(err); }
});

app.addEventListener('input', e => {
  const t = e.target;
  if (t.id === 'q' || t.id === 'qd') {
    if (t.id === 'q') q = t.value; else qd = t.value;
    const pos = t.selectionStart; render();
    const n = document.getElementById(t.id); if (n) { n.focus(); try { n.setSelectionRange(pos, pos); } catch (x) { /* abaikan */ } }
  } else if (t.id && t.id.startsWith('f_') && draft) draft[t.id.slice(2)] = t.value;
});

window.addEventListener('error', e => fatal(e.error || e.message));
window.addEventListener('unhandledrejection', e => fatal(e.reason));
render();
