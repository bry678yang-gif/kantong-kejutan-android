// Aturan bisnis murni: tanpa DOM, tanpa localStorage. Semua fungsi menerima `now` (ms).
// State diubah di tempat (mutasi); hasil berupa { ok:true, ... } atau { ok:false, error }.

export const STATUS = { DIPESAN: 'Dipesan', DIAMBIL: 'Diambil', HANGUS: 'Hangus' };
export const TIPE = { KEJUTAN: 'kejutan', ITEM: 'item' };
export const MAKS_JUMLAH = 1000;
export const METODE = { AMBIL: 'ambil', ANTAR: 'antar' };
export const BAYAR = { KARTU: 'kartu', QRIS: 'qris', TUNAI: 'tunai' };
export const KODE_PREFIX = 'KK:'; // isi QR Kode Ambil: "KK:" + 6 karakter kode
export const MAKS_CATATAN = 140;

// Koordinat toko = ILUSTRASI (perkiraan tengah area), hanya untuk menghitung jarak dari lokasi pembeli.
export const STORE_COORDS = { s1: [-7.2575, 112.7521], s2: [-7.2655, 112.7480], s3: [-7.2740, 112.7440], s4: [-7.2617, 112.7388], s5: [-7.2639, 112.7357], s6: [-7.2917, 112.7183] };
export const AREAS = [
  { nama: 'Tunjungan', lat: -7.2617, lng: 112.7388 }, { nama: 'Embong Malang', lat: -7.2639, lng: 112.7357 },
  { nama: 'Gubeng', lat: -7.2650, lng: 112.7522 }, { nama: 'Darmo', lat: -7.2893, lng: 112.7391 },
  { nama: 'Sungkono', lat: -7.2917, lng: 112.7183 }, { nama: 'Wonokromo', lat: -7.3040, lng: 112.7365 },
  { nama: 'Rungkut', lat: -7.3283, lng: 112.7733 }, { nama: 'Kenjeran', lat: -7.2290, lng: 112.7920 },
];
export const SBY_BOUNDS = { latMin: -7.40, latMax: -7.15, lngMin: 112.55, lngMax: 112.85 };

// Voucher yang bisa "ditambahkan" lewat kode (demo). Voucher awal pembeli ada di seedBuyer().
export const VOUCHER_KATALOG = [
  { code: 'HEMAT5K', judul: 'Diskon Rp5.000', jenis: 'nominal', nilai: 5000, minBelanja: 20000 },
  { code: 'ONGKIR0', judul: 'Gratis Ongkir', jenis: 'ongkir', nilai: 20000, minBelanja: 0 },
  { code: 'SDG12', judul: 'Diskon 10% (maks Rp10.000)', jenis: 'persen', nilai: 10, maks: 10000, minBelanja: 15000 },
  { code: 'SELAMATKAN', judul: 'Diskon 15% (maks Rp12.000)', jenis: 'persen', nilai: 15, maks: 12000, minBelanja: 25000 },
];

// Parameter estimasi dampak. ANGKA DEMO: ganti dengan faktor dari sumber resmi sebelum presentasi final.
export const IMPACT_PARAMS = {
  kgPerUnit: 0.4,   // perkiraan berat makanan per kantong/item (demo)
  co2PerKg: 2.5,    // kg CO2e per kg makanan terbuang (demo)
  sumber: 'Parameter demo, belum bersumber resmi. Ganti dengan faktor emisi dari sumber yang dapat dirujuk sebelum dipresentasikan.',
};

const KODE_ALFABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // 32 karakter, tanpa I dan O
const KODE_PANJANG = 6;

export function seedState(now) {
  const H = 3600000;
  const stores = [
    { id: 's1', nama: 'J.CO Donuts & Coffee', area: 'Cabang Surabaya', jarakKm: 0.6 },
    { id: 's2', nama: 'Bon Ami Bakery', area: 'Cabang Surabaya', jarakKm: 1.1 },
    { id: 's3', nama: 'Holland Bakery', area: 'Cabang Surabaya', jarakKm: 1.8 },
    { id: 's4', nama: 'Hotel Majapahit Surabaya', area: 'Tunjungan', jarakKm: 2.4 },
    { id: 's5', nama: 'JW Marriott Hotel Surabaya', area: 'Embong Malang', jarakKm: 3.0 },
    { id: 's6', nama: 'Shangri-La Hotel Surabaya', area: 'Sungkono', jarakKm: 4.2 },
  ];
  const mk = (n, storeId, type, nama, harga, jumlah) => ({
    id: 'L' + n, storeId, type, nama, harga, stokAwal: jumlah, stok: jumlah,
    jualStart: now - H, ambilStart: now + 0.5 * H, ambilEnd: now + 4 * H, jualEnd: now + 4 * H, createdAt: now - H,
  });
  // Merek, produk, harga, dan jarak = data ILUSTRASI untuk demo (bukan data resmi, belum ada kerja sama).
  const listings = [
    mk(1, 's1', TIPE.KEJUTAN, '', 25000, 5), mk(2, 's1', TIPE.ITEM, 'Donat Cokelat Kacang', 9000, 6), mk(3, 's1', TIPE.ITEM, 'Donat Gula Halus (3 pcs)', 15000, 4),
    mk(4, 's2', TIPE.KEJUTAN, '', 20000, 4), mk(5, 's2', TIPE.ITEM, 'Roti Sobek Cokelat', 12000, 5), mk(6, 's2', TIPE.ITEM, 'Roti Tawar Gandum', 18000, 3),
    mk(7, 's3', TIPE.KEJUTAN, '', 22000, 4), mk(8, 's3', TIPE.ITEM, 'Bolu Gulung Cokelat', 15000, 4), mk(9, 's3', TIPE.ITEM, 'Roti Abon Sapi', 8000, 6),
    mk(10, 's4', TIPE.KEJUTAN, '', 45000, 3), mk(11, 's4', TIPE.ITEM, 'Croissant Mentega', 25000, 4), mk(12, 's4', TIPE.ITEM, 'Potongan Cheesecake', 30000, 3),
    mk(13, 's5', TIPE.KEJUTAN, '', 55000, 3), mk(14, 's5', TIPE.ITEM, 'Danish Pastry Buah', 28000, 4), mk(15, 's5', TIPE.ITEM, 'Muffin Blueberry', 22000, 5),
    mk(16, 's6', TIPE.KEJUTAN, '', 60000, 2), mk(17, 's6', TIPE.ITEM, 'Potongan Red Velvet', 32000, 3), mk(18, 's6', TIPE.ITEM, 'Cookies Cokelat Chip (4 pcs)', 20000, 5),
  ];
  stores.forEach(st => { st.lat = STORE_COORDS[st.id][0]; st.lng = STORE_COORDS[st.id][1]; });
  return { stores, listings, orders: [], buyer: seedBuyer(), meta: { version: 1, offsetMs: 0, nextListingId: 19, nextOrderId: 1 } };
}

export function seedBuyer() {
  const v = c => ({ ...VOUCHER_KATALOG.find(x => x.code === c), dipakai: false });
  return { nama: 'Pembeli Demo', alamat: '', lat: null, lng: null, lokasiOk: false, vouchers: [v('HEMAT5K'), v('ONGKIR0')] };
}

// Melengkapi data lama dari penyimpanan (sebelum ada buyer / koordinat toko). Aman dipanggil berulang.
export function migrateState(s) {
  if (!s.buyer || typeof s.buyer !== 'object') s.buyer = seedBuyer();
  const b = s.buyer;
  if (typeof b.nama !== 'string' || !b.nama.trim()) b.nama = 'Pembeli Demo';
  if (typeof b.alamat !== 'string') b.alamat = '';
  if (!Number.isFinite(b.lat) || !Number.isFinite(b.lng)) { b.lat = null; b.lng = null; b.lokasiOk = false; }
  if (!Array.isArray(b.vouchers)) b.vouchers = seedBuyer().vouchers;
  for (const st of s.stores) if (STORE_COORDS[st.id] && !Number.isFinite(st.lat)) { st.lat = STORE_COORDS[st.id][0]; st.lng = STORE_COORDS[st.id][1]; }
  return s;
}

export function haversineKm(lat1, lng1, lat2, lng2) {
  const R = 6371, rad = d => d * Math.PI / 180, dLat = rad(lat2 - lat1), dLng = rad(lng2 - lng1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(rad(lat1)) * Math.cos(rad(lat2)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}
export function inSurabaya(lat, lng) {
  return Number.isFinite(lat) && Number.isFinite(lng) && lat >= SBY_BOUNDS.latMin && lat <= SBY_BOUNDS.latMax && lng >= SBY_BOUNDS.lngMin && lng <= SBY_BOUNDS.lngMax;
}
export function nearestArea(lat, lng) {
  let best = null, bd = Infinity;
  for (const a of AREAS) { const d = haversineKm(lat, lng, a.lat, a.lng); if (d < bd) { bd = d; best = a; } }
  return { area: best, km: Math.round(bd * 10) / 10 };
}
// Jarak toko ke pembeli. Memakai lokasi terverifikasi di Surabaya; selain itu kembali ke jarak contoh.
export function storeDistance(store, buyer) {
  if (buyer && buyer.lokasiOk && inSurabaya(buyer.lat, buyer.lng) && Number.isFinite(store.lat)) {
    return Math.max(0.1, Math.round(haversineKm(buyer.lat, buyer.lng, store.lat, store.lng) * 10) / 10);
  }
  return store.jarakKm;
}

// Ongkir simulasi: dasar Rp4.000 + Rp2.000/km, dibulatkan ke atas per Rp500.
export function ongkirFor(jarakKm) { return Math.ceil((4000 + 2000 * Math.max(0, jarakKm)) / 500) * 500; }

export function updateBuyer(state, patch) {
  const b = state.buyer, errors = [];
  if ('nama' in patch) { const n = String(patch.nama || '').trim(); if (!n) errors.push('Nama tidak boleh kosong.'); else if (n.length > 40) errors.push('Nama maksimal 40 karakter.'); else b.nama = n; }
  if ('alamat' in patch) { const a = String(patch.alamat || '').trim(); if (a.length > 200) errors.push('Alamat maksimal 200 karakter.'); else b.alamat = a; }
  if ('lat' in patch) {
    if (patch.lat === null) { b.lat = null; b.lng = null; b.lokasiOk = false; }
    else if (Number.isFinite(patch.lat) && Number.isFinite(patch.lng)) { b.lat = patch.lat; b.lng = patch.lng; b.lokasiOk = inSurabaya(patch.lat, patch.lng); }
  }
  return errors.length ? { ok: false, errors, error: errors[0] } : { ok: true };
}

export function addVoucher(state, rawCode) {
  const code = String(rawCode || '').trim().toUpperCase();
  if (!code) return { ok: false, error: 'Masukkan kode voucher.' };
  if (state.buyer.vouchers.some(v => v.code === code)) return { ok: false, error: 'Voucher ini sudah ada di Inventori.' };
  const def = VOUCHER_KATALOG.find(v => v.code === code);
  if (!def) return { ok: false, error: 'Kode voucher tidak dikenal.' };
  const v = { ...def, dipakai: false }; state.buyer.vouchers.push(v);
  return { ok: true, voucher: v };
}

// Potongan dari satu voucher. Mengembalikan { ok, diskon } atau { ok:false, error }.
export function applyVoucher(v, subtotal, ongkir) {
  if (!v) return { ok: false, error: 'Voucher tidak ditemukan.' };
  if (v.dipakai) return { ok: false, error: 'Voucher sudah dipakai.' };
  if (subtotal < (v.minBelanja || 0)) return { ok: false, error: `Minimal belanja Rp${Number(v.minBelanja).toLocaleString('id-ID')} untuk voucher ini.` };
  if (v.jenis === 'nominal') return { ok: true, diskon: Math.min(v.nilai, subtotal) };
  if (v.jenis === 'persen') return { ok: true, diskon: Math.min(Math.floor(subtotal * v.nilai / 100), v.maks ?? Infinity, subtotal) };
  if (v.jenis === 'ongkir') return ongkir > 0 ? { ok: true, diskon: Math.min(v.nilai, ongkir) } : { ok: false, error: 'Voucher ongkir hanya berlaku untuk pesanan Antar.' };
  return { ok: false, error: 'Jenis voucher tidak dikenal.' };
}

// Luhn untuk nomor kartu (simulasi; nomor TIDAK pernah disimpan, hanya 4 digit terakhir).
export function luhnOk(num) {
  const d = String(num).replace(/\D/g, ''); if (d.length < 13 || d.length > 19) return false;
  let sum = 0, alt = false; for (let i = d.length - 1; i >= 0; i--) { let n = +d[i]; if (alt) { n *= 2; if (n > 9) n -= 9; } sum += n; alt = !alt; }
  return sum % 10 === 0;
}
export function validateCard(k, now) {
  const errors = [], num = String(k && k.nomor || '').replace(/\D/g, '');
  if (!luhnOk(num)) errors.push('Nomor kartu tidak valid.');
  const m = /^(\d{2})\/(\d{2})$/.exec(String(k && k.exp || '').trim());
  if (!m || +m[1] < 1 || +m[1] > 12) errors.push('Masa berlaku harus berformat BB/TT.');
  else { const d = new Date(now), y = d.getFullYear() % 100, mo = d.getMonth() + 1; if (+m[2] < y || (+m[2] === y && +m[1] < mo)) errors.push('Kartu sudah kedaluwarsa.'); }
  if (!/^\d{3,4}$/.test(String(k && k.cvv || ''))) errors.push('CVV harus 3 atau 4 digit.');
  return { ok: errors.length === 0, errors, last4: num.slice(-4) };
}

// Rincian harga (murni). opts: { metode, voucherCode }
export function priceBreakdown(state, listing, n, opts = {}) {
  const store = state.stores.find(x => x.id === listing.storeId);
  const subtotal = listing.harga * n, metode = opts.metode === METODE.ANTAR ? METODE.ANTAR : METODE.AMBIL;
  const jarak = store ? storeDistance(store, state.buyer) : 0;
  const ongkir = metode === METODE.ANTAR ? ongkirFor(jarak) : 0;
  let diskon = 0, voucher = null, voucherError = null;
  if (opts.voucherCode) {
    voucher = (state.buyer.vouchers || []).find(v => v.code === opts.voucherCode) || null;
    const r = applyVoucher(voucher, subtotal, ongkir);
    if (r.ok) diskon = r.diskon; else { voucherError = r.error; voucher = null; }
  }
  return { subtotal, ongkir, diskon, total: Math.max(0, subtotal + ongkir - diskon), voucher, voucherError, metode, jarak };
}

export function todayAt(hhmm, now) {
  const m = /^(\d{1,2}):(\d{2})$/.exec(String(hhmm || '').trim());
  if (!m) return NaN;
  const h = Number(m[1]), mi = Number(m[2]);
  if (h > 23 || mi > 59) return NaN;
  const d = new Date(now); d.setHours(h, mi, 0, 0);
  return d.getTime();
}

export function validateListing(input, now) {
  const errors = [];
  const { type, jumlah, harga, nama, ambilStart, ambilEnd } = input || {};
  if (type !== TIPE.KEJUTAN && type !== TIPE.ITEM) errors.push('Pilih jenis listing: Paket Kejutan atau Item Pilihan.');
  if (type === TIPE.ITEM && !String(nama || '').trim()) errors.push('Nama produk wajib diisi untuk Item Pilihan.');
  if (!Number.isInteger(jumlah) || jumlah <= 0) errors.push('Jumlah harus bilangan bulat lebih dari 0.');
  else if (jumlah > MAKS_JUMLAH) errors.push(`Jumlah maksimal ${MAKS_JUMLAH}.`);
  if (!Number.isInteger(harga) || harga <= 0) errors.push('Harga harus bilangan bulat rupiah lebih dari 0.');
  if (!Number.isFinite(ambilStart) || !Number.isFinite(ambilEnd)) errors.push('Isi jam mulai dan jam selesai pengambilan.');
  else if (ambilEnd <= ambilStart) errors.push('Jam selesai pengambilan harus setelah jam mulai.');
  else if (ambilEnd <= now) errors.push('Jam selesai pengambilan sudah lewat.');
  const foto = input && input.foto;
  if (foto != null && !fotoOk(foto)) errors.push('Foto tidak valid atau terlalu besar.');
  return { ok: errors.length === 0, errors };
}

export const MAKS_FOTO_CHAR = 400000; // ~300 KB data URL; app mengecilkan foto sebelum disimpan
export const fotoOk = f => typeof f === 'string' && /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(f) && f.length <= MAKS_FOTO_CHAR;

export function createListing(state, storeId, input, now) {
  const v = validateListing(input, now);
  if (!v.ok) return { ok: false, errors: v.errors, error: v.errors[0] };
  if (!state.stores.some(s => s.id === storeId)) return { ok: false, errors: ['Toko tidak ditemukan.'], error: 'Toko tidak ditemukan.' };
  const listing = {
    id: 'L' + state.meta.nextListingId++, storeId, type: input.type,
    nama: input.type === TIPE.ITEM ? String(input.nama).trim() : '',
    harga: input.harga, stokAwal: input.jumlah, stok: input.jumlah, foto: input.foto || null,
    jualStart: now, jualEnd: input.ambilEnd, ambilStart: input.ambilStart, ambilEnd: input.ambilEnd, createdAt: now,
  };
  state.listings.push(listing);
  return { ok: true, listing };
}

export function deleteListing(state, storeId, listingId) {
  const i = state.listings.findIndex(l => l.id === listingId && l.storeId === storeId);
  if (i < 0) return { ok: false, error: 'Listing tidak ditemukan di toko ini.' };
  const pending = state.orders.filter(o => o.listingId === listingId && o.status === STATUS.DIPESAN).length;
  if (pending > 0) return { ok: false, error: `Masih ada ${pending} pesanan berstatus Dipesan untuk listing ini. Verifikasi atau tunggu sampai hangus dulu.` };
  const [removed] = state.listings.splice(i, 1);
  return { ok: true, listing: removed };
}

export function setListingFoto(state, storeId, listingId, foto) {
  const l = state.listings.find(x => x.id === listingId && x.storeId === storeId);
  if (!l) return { ok: false, error: 'Listing tidak ditemukan di toko ini.' };
  if (foto !== null && !fotoOk(foto)) return { ok: false, error: 'Foto tidak valid atau terlalu besar.' };
  l.foto = foto; return { ok: true };
}

// Daftar putih kolom untuk Pembeli: tidak ada harga coret, tidak ada isi paket (CP-6).
export function buyerView(l, store, buyer) {
  return {
    id: l.id, tipe: l.type, foto: l.foto || null,
    judul: l.type === TIPE.KEJUTAN ? 'Paket Kejutan' : l.nama,
    harga: l.harga, stok: l.stok, ambilStart: l.ambilStart, ambilEnd: l.ambilEnd,
    tokoId: store ? store.id : l.storeId, tokoNama: store ? store.nama : '', area: store ? store.area : '', jarakKm: store ? storeDistance(store, buyer) : 0,
  };
}

export function activeListings(state, now) {
  return state.listings
    .filter(l => l.stok > 0 && now >= l.jualStart && now < l.jualEnd)
    .map(l => buyerView(l, state.stores.find(s => s.id === l.storeId), state.buyer))
    .sort((a, b) => a.jarakKm - b.jarakKm || a.ambilEnd - b.ambilEnd);
}

export function remainingStock(listing, orders) {
  return listing.stokAwal - orders.filter(o => o.listingId === listing.id).reduce((a, o) => a + o.qty, 0);
}

function newCode(taken, rng) {
  const space = Math.pow(KODE_ALFABET.length, KODE_PANJANG);
  let num = Math.floor(rng() * space);
  for (let i = 0; i < space; i++, num = (num + 1) % space) {
    let x = num, code = '';
    for (let k = 0; k < KODE_PANJANG; k++) { code = KODE_ALFABET[x % KODE_ALFABET.length] + code; x = Math.floor(x / KODE_ALFABET.length); }
    if (!taken.has(code)) return code;
  }
  throw new Error('Kode Ambil habis');
}

export function placeOrder(state, listingId, n, now, rng = Math.random, opts = null) {
  const l = state.listings.find(x => x.id === listingId);
  if (!l) return { ok: false, error: 'Listing tidak ditemukan.' };
  if (now < l.jualStart || now >= l.jualEnd) return { ok: false, error: 'Listing ini sudah tidak dijual. Kembali ke daftar.' };
  if (l.stok <= 0) return { ok: false, error: 'Stok habis. Kembali ke daftar.' };
  if (typeof n !== 'number' || !Number.isInteger(n) || n < 1) return { ok: false, error: 'Jumlah pesanan minimal 1.' };
  if (n > l.stok) return { ok: false, error: `Stok tersedia hanya ${l.stok}.` };
  let price = { subtotal: l.harga * n, ongkir: 0, diskon: 0, total: l.harga * n, voucher: null, metode: METODE.AMBIL };
  let extra = {};
  if (opts) {
    const bad = msg => ({ ok: false, error: msg, kind: 'input' });
    price = priceBreakdown(state, l, n, opts);
    if (opts.voucherCode && !price.voucher) return bad(price.voucherError || 'Voucher tidak bisa dipakai.');
    if (price.metode === METODE.ANTAR && !String(opts.alamat || '').trim()) return bad('Isi alamat pengantaran di Profil dulu, atau pilih Ambil di toko.');
    const catatan = String(opts.catatan || '').trim();
    if (catatan.length > MAKS_CATATAN) return bad(`Catatan maksimal ${MAKS_CATATAN} karakter.`);
    const bm = opts.bayar && opts.bayar.metode;
    if (!Object.values(BAYAR).includes(bm)) return bad('Pilih metode pembayaran.');
    let kartu4 = null;
    if (bm === BAYAR.KARTU) { const c = validateCard(opts.bayar, now); if (!c.ok) return bad(c.errors[0]); kartu4 = c.last4; }
    extra = {
      metode: price.metode, alamat: price.metode === METODE.ANTAR ? String(opts.alamat).trim() : '', catatan,
      voucher: price.voucher ? price.voucher.code : null,
      bayar: bm, statusBayar: bm === BAYAR.TUNAI ? 'Bayar di tempat' : 'Lunas', kartu4,
    };
  }
  const order = {
    id: 'O' + state.meta.nextOrderId++, listingId: l.id, storeId: l.storeId, type: l.type,
    judul: l.type === TIPE.KEJUTAN ? 'Paket Kejutan' : l.nama,
    qty: n, unitPrice: l.harga, subtotal: price.subtotal, ongkir: price.ongkir, diskon: price.diskon, total: price.total, ...extra,
    code: newCode(new Set(state.orders.map(o => o.code)), rng),
    status: STATUS.DIPESAN, createdAt: now, ambilStart: l.ambilStart, ambilEnd: l.ambilEnd,
  };
  l.stok -= n;
  if (price.voucher) price.voucher.dipakai = true;
  state.orders.push(order);
  return { ok: true, order };
}

export function expireOrders(state, now) {
  let count = 0;
  for (const o of state.orders) if (o.status === STATUS.DIPESAN && now > o.ambilEnd) { o.status = STATUS.HANGUS; count++; }
  return count;
}

// Menerima kode ketikan ("K7H2PQ") atau isi QR ("KK:K7H2PQ"). Mengembalikan kode bersih atau ''.
export function parseCodeInput(raw) {
  let c = String(raw || '').trim().toUpperCase();
  if (c.startsWith(KODE_PREFIX)) c = c.slice(KODE_PREFIX.length);
  return c.trim();
}

export function verifyCode(state, storeId, rawCode, now) {
  const code = parseCodeInput(rawCode);
  if (!code) return { ok: false, error: 'Masukkan Kode Ambil.' };
  const o = state.orders.find(x => x.code === code && x.storeId === storeId);
  if (!o) return { ok: false, error: 'Kode tidak ditemukan di toko ini.' };
  if (o.status === STATUS.DIPESAN && now > o.ambilEnd) o.status = STATUS.HANGUS;
  if (o.status === STATUS.DIAMBIL) return { ok: false, error: 'Kode sudah dipakai: pesanan ini sudah diambil.' };
  if (o.status === STATUS.HANGUS) return { ok: false, error: 'Pesanan hangus: Jendela Ambil sudah berakhir.' };
  o.status = STATUS.DIAMBIL; o.pickedAt = now;
  if (o.bayar === BAYAR.TUNAI) o.statusBayar = 'Lunas';
  return { ok: true, order: o };
}

export function computeImpact(state) {
  const taken = state.orders.filter(o => o.status === STATUS.DIAMBIL);
  const unit = taken.reduce((a, o) => a + o.qty, 0);
  const rupiah = taken.reduce((a, o) => a + (Number.isFinite(o.subtotal) ? o.subtotal : o.total), 0);
  const kg = unit * IMPACT_PARAMS.kgPerUnit;
  const co2Kg = Math.round(kg * IMPACT_PARAMS.co2PerKg * 10) / 10;
  return {
    unit, rupiah, kg: Math.round(kg * 10) / 10, co2Kg, orders: taken.length,
    params: IMPACT_PARAMS, sumber: IMPACT_PARAMS.sumber,
    catatan: 'Angka CO2 adalah estimasi dari parameter demo; hanya dihitung dari pesanan berstatus Diambil.',
  };
}

// Pemeriksaan bentuk data hasil muat dari penyimpanan (data rusak -> false).
export function isValidState(s) {
  return !!s && Array.isArray(s.stores) && Array.isArray(s.listings) && Array.isArray(s.orders) && !!s.meta &&
    Number.isFinite(s.meta.offsetMs) && Number.isInteger(s.meta.nextListingId) && Number.isInteger(s.meta.nextOrderId) &&
    s.listings.every(l => l && typeof l.id === 'string' && Number.isFinite(l.stok) && Number.isFinite(l.harga)) &&
    s.orders.every(o => o && typeof o.code === 'string' && typeof o.status === 'string');
}
