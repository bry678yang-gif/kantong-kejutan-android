// Aturan bisnis murni: tanpa DOM, tanpa localStorage. Semua fungsi menerima `now` (ms).
// State diubah di tempat (mutasi); hasil berupa { ok:true, ... } atau { ok:false, error }.

export const STATUS = { DIPESAN: 'Dipesan', DIAMBIL: 'Diambil', HANGUS: 'Hangus' };
export const TIPE = { KEJUTAN: 'kejutan', ITEM: 'item' };
export const MAKS_JUMLAH = 1000;

// Parameter estimasi dampak. ANGKA DEMO: ganti dengan faktor dari sumber resmi sebelum presentasi final.
export const IMPACT_PARAMS = {
  kgPerUnit: 0.4,   // perkiraan berat makanan per kantong/item (demo)
  co2PerKg: 2.5,    // kg CO2e per kg makanan terbuang (demo)
  sumber: 'Parameter demo, belum bersumber resmi. Ganti dengan faktor emisi dari sumber yang dapat dirujuk sebelum dipresentasikan.',
};

const KODE_ALFABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // 32 karakter, tanpa I dan O
const KODE_PANJANG = 6;

export function seedState(now) {
  const H = 3600000;
  const stores = [
    { id: 's1', nama: 'Roti Bahagia Darmo', area: 'Darmo', jarakKm: 0.4 },
    { id: 's2', nama: 'Donat Senja Gubeng', area: 'Gubeng', jarakKm: 0.9 },
    { id: 's3', nama: 'Dapur Roti Tegalsari', area: 'Tegalsari', jarakKm: 1.6 },
    { id: 's4', nama: 'Kue Manis Rungkut', area: 'Rungkut', jarakKm: 2.3 },
  ];
  const mk = (n, storeId, type, nama, harga, jumlah) => ({
    id: 'L' + n, storeId, type, nama, harga, stokAwal: jumlah, stok: jumlah,
    jualStart: now - H, ambilStart: now + 0.5 * H, ambilEnd: now + 4 * H, jualEnd: now + 4 * H, createdAt: now - H,
  });
  const listings = [
    mk(1, 's1', TIPE.KEJUTAN, '', 15000, 5),
    mk(2, 's1', TIPE.ITEM, 'Roti sobek cokelat', 8000, 6),
    mk(3, 's2', TIPE.KEJUTAN, '', 12000, 4),
    mk(4, 's2', TIPE.ITEM, 'Donat gula halus (3 pcs)', 9000, 3),
    mk(5, 's3', TIPE.ITEM, 'Roti tawar gandum', 10000, 4),
    mk(6, 's4', TIPE.KEJUTAN, '', 18000, 3),
  ];
  return { stores, listings, orders: [], meta: { version: 1, offsetMs: 0, nextListingId: 7, nextOrderId: 1 } };
}

export function todayAt(hhmm, now) {
  const m = /^(\d{1,2}):(\d{2})$/.exec(String(hhmm || '').trim());
  if (!m) return NaN;
  const h = Number(m[1]), mi = Number(m[2]);
  if (h > 23 || mi > 59) return NaN;
  const d = new Date(now); d.setHours(h, mi, 0, 0);
  return d.getTime();
}

export function validateListing(input, now) {
  const errors = [];
  const { type, jumlah, harga, nama, ambilStart, ambilEnd } = input || {};
  if (type !== TIPE.KEJUTAN && type !== TIPE.ITEM) errors.push('Pilih jenis listing: Paket Kejutan atau Item Pilihan.');
  if (type === TIPE.ITEM && !String(nama || '').trim()) errors.push('Nama produk wajib diisi untuk Item Pilihan.');
  if (!Number.isInteger(jumlah) || jumlah <= 0) errors.push('Jumlah harus bilangan bulat lebih dari 0.');
  else if (jumlah > MAKS_JUMLAH) errors.push(`Jumlah maksimal ${MAKS_JUMLAH}.`);
  if (!Number.isInteger(harga) || harga <= 0) errors.push('Harga harus bilangan bulat rupiah lebih dari 0.');
  if (!Number.isFinite(ambilStart) || !Number.isFinite(ambilEnd)) errors.push('Isi jam mulai dan jam selesai pengambilan.');
  else if (ambilEnd <= ambilStart) errors.push('Jam selesai pengambilan harus setelah jam mulai.');
  else if (ambilEnd <= now) errors.push('Jam selesai pengambilan sudah lewat.');
  return { ok: errors.length === 0, errors };
}

export function createListing(state, storeId, input, now) {
  const v = validateListing(input, now);
  if (!v.ok) return { ok: false, errors: v.errors, error: v.errors[0] };
  if (!state.stores.some(s => s.id === storeId)) return { ok: false, errors: ['Toko tidak ditemukan.'], error: 'Toko tidak ditemukan.' };
  const listing = {
    id: 'L' + state.meta.nextListingId++, storeId, type: input.type,
    nama: input.type === TIPE.ITEM ? String(input.nama).trim() : '',
    harga: input.harga, stokAwal: input.jumlah, stok: input.jumlah,
    jualStart: now, jualEnd: input.ambilEnd, ambilStart: input.ambilStart, ambilEnd: input.ambilEnd, createdAt: now,
  };
  state.listings.push(listing);
  return { ok: true, listing };
}

// Daftar putih kolom untuk Pembeli: tidak ada harga coret, tidak ada isi paket (CP-6).
export function buyerView(l, store) {
  return {
    id: l.id, tipe: l.type,
    judul: l.type === TIPE.KEJUTAN ? 'Paket Kejutan' : l.nama,
    harga: l.harga, stok: l.stok, ambilStart: l.ambilStart, ambilEnd: l.ambilEnd,
    tokoId: store ? store.id : l.storeId, tokoNama: store ? store.nama : '', area: store ? store.area : '', jarakKm: store ? store.jarakKm : 0,
  };
}

export function activeListings(state, now) {
  return state.listings
    .filter(l => l.stok > 0 && now >= l.jualStart && now < l.jualEnd)
    .map(l => buyerView(l, state.stores.find(s => s.id === l.storeId)))
    .sort((a, b) => a.jarakKm - b.jarakKm || a.ambilEnd - b.ambilEnd);
}

export function remainingStock(listing, orders) {
  return listing.stokAwal - orders.filter(o => o.listingId === listing.id).reduce((a, o) => a + o.qty, 0);
}

function newCode(taken, rng) {
  const space = Math.pow(KODE_ALFABET.length, KODE_PANJANG);
  let num = Math.floor(rng() * space);
  for (let i = 0; i < space; i++, num = (num + 1) % space) {
    let x = num, code = '';
    for (let k = 0; k < KODE_PANJANG; k++) { code = KODE_ALFABET[x % KODE_ALFABET.length] + code; x = Math.floor(x / KODE_ALFABET.length); }
    if (!taken.has(code)) return code;
  }
  throw new Error('Kode Ambil habis');
}

export function placeOrder(state, listingId, n, now, rng = Math.random) {
  const l = state.listings.find(x => x.id === listingId);
  if (!l) return { ok: false, error: 'Listing tidak ditemukan.' };
  if (now < l.jualStart || now >= l.jualEnd) return { ok: false, error: 'Listing ini sudah tidak dijual. Kembali ke daftar.' };
  if (l.stok <= 0) return { ok: false, error: 'Stok habis. Kembali ke daftar.' };
  if (typeof n !== 'number' || !Number.isInteger(n) || n < 1) return { ok: false, error: 'Jumlah pesanan minimal 1.' };
  if (n > l.stok) return { ok: false, error: `Stok tersedia hanya ${l.stok}.` };
  const order = {
    id: 'O' + state.meta.nextOrderId++, listingId: l.id, storeId: l.storeId, type: l.type,
    judul: l.type === TIPE.KEJUTAN ? 'Paket Kejutan' : l.nama,
    qty: n, unitPrice: l.harga, total: l.harga * n,
    code: newCode(new Set(state.orders.map(o => o.code)), rng),
    status: STATUS.DIPESAN, createdAt: now, ambilStart: l.ambilStart, ambilEnd: l.ambilEnd,
  };
  l.stok -= n;
  state.orders.push(order);
  return { ok: true, order };
}

export function expireOrders(state, now) {
  let count = 0;
  for (const o of state.orders) if (o.status === STATUS.DIPESAN && now > o.ambilEnd) { o.status = STATUS.HANGUS; count++; }
  return count;
}

export function verifyCode(state, storeId, rawCode, now) {
  const code = String(rawCode || '').trim().toUpperCase();
  if (!code) return { ok: false, error: 'Masukkan Kode Ambil.' };
  const o = state.orders.find(x => x.code === code && x.storeId === storeId);
  if (!o) return { ok: false, error: 'Kode tidak ditemukan di toko ini.' };
  if (o.status === STATUS.DIPESAN && now > o.ambilEnd) o.status = STATUS.HANGUS;
  if (o.status === STATUS.DIAMBIL) return { ok: false, error: 'Kode sudah dipakai: pesanan ini sudah diambil.' };
  if (o.status === STATUS.HANGUS) return { ok: false, error: 'Pesanan hangus: Jendela Ambil sudah berakhir.' };
  o.status = STATUS.DIAMBIL; o.pickedAt = now;
  return { ok: true, order: o };
}

export function computeImpact(state) {
  const taken = state.orders.filter(o => o.status === STATUS.DIAMBIL);
  const unit = taken.reduce((a, o) => a + o.qty, 0);
  const rupiah = taken.reduce((a, o) => a + o.total, 0);
  const kg = unit * IMPACT_PARAMS.kgPerUnit;
  const co2Kg = Math.round(kg * IMPACT_PARAMS.co2PerKg * 10) / 10;
  return {
    unit, rupiah, kg: Math.round(kg * 10) / 10, co2Kg, orders: taken.length,
    params: IMPACT_PARAMS, sumber: IMPACT_PARAMS.sumber,
    catatan: 'Angka CO2 adalah estimasi dari parameter demo; hanya dihitung dari pesanan berstatus Diambil.',
  };
}

// Pemeriksaan bentuk data hasil muat dari penyimpanan (data rusak -> false).
export function isValidState(s) {
  return !!s && Array.isArray(s.stores) && Array.isArray(s.listings) && Array.isArray(s.orders) && !!s.meta &&
    Number.isFinite(s.meta.offsetMs) && Number.isInteger(s.meta.nextListingId) && Number.isInteger(s.meta.nextOrderId) &&
    s.listings.every(l => l && typeof l.id === 'string' && Number.isFinite(l.stok) && Number.isFinite(l.harga)) &&
    s.orders.every(o => o && typeof o.code === 'string' && typeof o.status === 'string');
}
