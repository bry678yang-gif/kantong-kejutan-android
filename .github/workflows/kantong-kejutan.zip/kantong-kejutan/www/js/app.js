import { STATUS, TIPE, activeListings, buyerView, createListing, placeOrder, verifyCode, expireOrders, computeImpact, todayAt } from './logic.js';
import { load, save, reset, loadUi, saveUi } from './store.js';

const app = document.getElementById('app');
const HOUR = 3600000;
const loaded = load(Date.now());
let state = loaded.state;
let corrupt = loaded.status === 'corrupt';
let noStorage = loaded.status === 'nostorage';
let ui = loadUi();
let view = ui.role === 'toko' ? { name: 'tdash' } : ui.role === 'pembeli' ? { name: 'home' } : { name: 'role' };
let flash = null;
let draft = null;

const now = () => Date.now() + state.meta.offsetMs;
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const rp = n => 'Rp' + Number(n).toLocaleString('id-ID');
const p2 = n => String(n).padStart(2, '0');
const jam = ms => { const d = new Date(ms); return p2(d.getHours()) + ':' + p2(d.getMinutes()); };
const range = (a, b) => `${jam(a)}–${jam(b)}`;
const storeOf = id => state.stores.find(s => s.id === id);
const badgeCls = st => st === STATUS.DIPESAN ? 'o' : st === STATUS.HANGUS ? 'r' : '';

let toastTimer;
function toast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg; t.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('show'), 2600);
}

function go(name, params = {}) { view = { name, ...params }; flash = null; render(); window.scrollTo(0, 0); }

function flashHtml() {
  if (!flash) return '';
  return `<div class="${flash.ok ? 'okbox' : 'err'}">${flash.html ?? esc(flash.msg)}</div>`;
}

const TERMS = 'Hanya produk sisa hari yang sama dan belum kedaluwarsa yang boleh dijual. Produk harus diambil pada Jendela Ambil. (Kejelasan aturan hukum pangan masih menunggu konsultasi.)';

function toolsHtml() {
  return `<div class="tools"><div class="mu">Alat demo · jam simulasi ${jam(now())}${state.meta.offsetMs ? ' (dimajukan)' : ''}</div>
  <div class="row" style="margin-top:8px;gap:8px"><button class="btn sec sm" data-act="advance">Majukan jam 1 jam</button><button class="btn sec sm" data-act="reset">Reset demo</button></div></div>`;
}

function layout(body, navKey) {
  const nav = ui.role === 'pembeli' ? [['home', 'Beranda'], ['orders', 'Pesanan'], ['impact', 'Dampak']]
    : ui.role === 'toko' ? [['tdash', 'Dashboard'], ['tcreate', 'Buat listing'], ['impact', 'Dampak']] : [];
  return `<div class="demo">MODE DEMO · data dan pembayaran adalah simulasi${noStorage ? ' · penyimpanan perangkat tidak tersedia' : ''}</div>
  <header class="top"><h1>Kantong Kejutan</h1>${ui.role ? `<button data-act="roles">Ganti peran</button>` : ''}</header>
  <main>${body}${toolsHtml()}</main>
  ${nav.length ? `<nav class="bottom">${nav.map(([k, l]) => `<button class="${k === navKey ? 'on' : ''}" data-act="nav" data-to="${k}">${l}</button>`).join('')}</nav>` : ''}`;
}

const V = {};

V.corrupt = () => `<div class="demo">MODE DEMO</div><main><h2>Data lokal rusak</h2><p>Data di perangkat tidak bisa dibaca. Reset demo akan memuat ulang data contoh.</p><button class="btn" data-act="reset" data-force="1">Reset demo</button></main>`;

V.role = () => layout(`<h2>Selamat datang</h2><p class="mu">Selamatkan makanan sisa hari ini di Surabaya. Pilih peran untuk mulai; tanpa login.</p>
  <div class="card"><b>Saya Pembeli</b><p class="mu">Cari paket dan item sisa dengan harga miring, lalu ambil di toko.</p><button class="btn" data-act="pickRole" data-role="pembeli">Masuk sebagai Pembeli</button></div>
  <div class="card"><b>Saya Toko</b><p class="mu">Unggah sisa produk menjelang tutup dan verifikasi Kode Ambil.</p>
  <label for="storeSel">Pilih toko demo</label><select id="storeSel">${state.stores.map(s => `<option value="${s.id}" ${s.id === ui.storeId ? 'selected' : ''}>${esc(s.nama)}</option>`).join('')}</select>
  <button class="btn warn" data-act="pickRole" data-role="toko">Masuk sebagai Toko</button></div>`, null);

V.home = () => {
  const list = activeListings(state, now());
  const cards = list.map(l => `<div class="card tap" data-act="detail" data-id="${esc(l.id)}">
    <div class="row"><b>${esc(l.judul)}</b><span class="badge ${l.tipe === TIPE.KEJUTAN ? 'o' : ''}">${l.tipe === TIPE.KEJUTAN ? 'Paket Kejutan' : 'Item Pilihan'}</span></div>
    <div class="mu">${esc(l.tokoNama)} · ${esc(l.area)} · ${l.jarakKm.toLocaleString('id-ID')} km</div>
    <div class="row" style="margin-top:8px"><span class="price">${rp(l.harga)}</span><span class="mu">Sisa ${l.stok} · Ambil ${range(l.ambilStart, l.ambilEnd)}</span></div></div>`).join('');
  return layout(`<h2>Dekat Anda</h2>${cards || '<div class="card mu">Belum ada listing aktif. Coba Majukan jam atau Reset demo.</div>'}`, 'home');
};

V.detail = () => {
  const l = state.listings.find(x => x.id === view.id);
  const act = activeListings(state, now()).find(x => x.id === view.id);
  if (!l || !act) return layout(`<h2>Listing tidak tersedia</h2><p>Stok habis atau waktu jual sudah berakhir.</p><button class="btn" data-act="nav" data-to="home">Kembali ke daftar</button>`, 'home');
  const kejutan = act.tipe === TIPE.KEJUTAN;
  const n = view.n ?? 1;
  return layout(`<button class="btn sec sm" data-act="nav" data-to="home">← Kembali</button>
  <h2 style="margin-top:12px">${esc(act.judul)}</h2>
  <div class="mu">${esc(act.tokoNama)} · ${esc(act.area)} · ${act.jarakKm.toLocaleString('id-ID')} km</div>
  <div class="card" style="margin-top:12px"><div class="price">${rp(act.harga)}</div><div class="mu">Sisa ${act.stok} · Ambil ${range(act.ambilStart, act.ambilEnd)}</div>
  ${kejutan ? '<p class="mu">Isi kantong dirahasiakan sampai pengambilan.</p>' : ''}</div>
  <div class="note">${esc(TERMS)}</div>
  <label for="qty">Jumlah</label><input id="qty" type="number" inputmode="numeric" min="1" max="${act.stok}" step="1" value="${esc(n)}" data-price="${act.harga}">
  <div class="row" style="margin-top:10px"><span>Total</span><b id="totalTxt">${rp(act.harga * (Number.isInteger(Number(n)) ? Number(n) : 0))}</b></div>
  ${flashHtml()}<button class="btn" data-act="toConfirm" data-id="${esc(act.id)}">Lanjut ke pembayaran (simulasi)</button>`, 'home');
};

V.confirm = () => {
  const l = state.listings.find(x => x.id === view.id);
  if (!l) return V.detail();
  const label = l.type === TIPE.KEJUTAN ? 'Paket Kejutan' : l.nama;
  return layout(`<h2>Konfirmasi pesanan</h2><div class="card"><b>${esc(label)}</b> × ${view.n}<div class="mu">${esc(storeOf(l.storeId).nama)}<br>Ambil ${range(l.ambilStart, l.ambilEnd)}</div>
  <div class="row" style="margin-top:10px"><span>Total</span><span class="price">${rp(l.harga * view.n)}</span></div></div>
  <div class="note"><b>Pembayaran SIMULASI.</b> Tidak ada uang sungguhan yang dipindahkan.</div>
  <button class="btn" data-act="pay" data-id="${esc(l.id)}" data-n="${view.n}">Bayar (simulasi)</button>
  <button class="btn sec" data-act="detail" data-id="${esc(l.id)}">Ubah jumlah</button>`, 'home');
};

V.order = () => {
  const o = state.orders.find(x => x.id === view.id);
  if (!o) return V.orders();
  return layout(`<h2>Pesanan ${o.status === STATUS.DIPESAN ? 'berhasil' : o.status.toLowerCase()}</h2><div class="code">${esc(o.code)}</div>
  <p class="mu" style="text-align:center">Tunjukkan Kode Ambil ini ke toko.</p>
  <div class="card"><div class="row"><b>${esc(o.judul)} × ${o.qty}</b><span class="badge ${badgeCls(o.status)}">${o.status}</span></div>
  <div class="mu">${esc(storeOf(o.storeId).nama)}<br>Ambil ${range(o.ambilStart, o.ambilEnd)}</div>
  <div class="row" style="margin-top:8px"><span>Total (pembayaran simulasi)</span><b>${rp(o.total)}</b></div></div>
  <div class="note">${esc(TERMS)} Pesanan yang tidak diambil sampai Jendela Ambil berakhir menjadi Hangus.</div>
  <button class="btn" data-act="nav" data-to="orders">Lihat semua pesanan</button><button class="btn sec" data-act="nav" data-to="home">Kembali ke daftar</button>`, 'orders');
};

V.orders = () => {
  const list = [...state.orders].reverse().map(o => `<div class="card tap" data-act="openOrder" data-id="${esc(o.id)}"><div class="row"><b>${esc(o.judul)} × ${o.qty}</b><span class="badge ${badgeCls(o.status)}">${o.status}</span></div>
    <div class="mu">${esc(storeOf(o.storeId).nama)} · ${rp(o.total)} · Kode ${esc(o.code)}</div></div>`).join('');
  return layout(`<h2>Pesanan saya</h2>${list || '<div class="card mu">Belum ada pesanan.</div>'}`, 'orders');
};

V.impact = () => {
  const i = computeImpact(state);
  return layout(`<h2>Dampak SDG 12</h2><p class="mu">Dihitung hanya dari pesanan berstatus Diambil (${i.orders} pesanan).</p>
  <div class="grid"><div class="card"><div class="big">${i.unit}</div><div class="mu">kantong/porsi terselamatkan</div></div>
  <div class="card"><div class="big" style="font-size:26px">${rp(i.rupiah)}</div><div class="mu">nilai pesanan diambil</div></div></div>
  <div class="card"><div class="big">${i.co2Kg.toLocaleString('id-ID')} kg</div><div class="mu">estimasi CO₂e terhindar (estimasi)</div></div>
  <div class="note">Parameter: ${i.params.kgPerUnit} kg makanan per kantong × ${i.params.co2PerKg} kg CO₂e per kg. ${esc(i.sumber)}</div>`, 'impact');
};

V.tdash = () => {
  const st = storeOf(ui.storeId) || state.stores[0];
  const orders = [...state.orders].filter(o => o.storeId === st.id).reverse().map(o => `<div class="card"><div class="row"><b>${esc(o.judul)} × ${o.qty}</b><span class="badge ${badgeCls(o.status)}">${o.status}</span></div><div class="mu">${rp(o.total)} · Ambil ${range(o.ambilStart, o.ambilEnd)}</div></div>`).join('');
  const mine = state.listings.filter(l => l.storeId === st.id).map(l => `<div class="card"><div class="row"><b>${esc(l.type === TIPE.KEJUTAN ? 'Paket Kejutan' : l.nama)}</b><span class="price">${rp(l.harga)}</span></div><div class="mu">Sisa ${l.stok} dari ${l.stokAwal} · Ambil ${range(l.ambilStart, l.ambilEnd)}</div></div>`).join('');
  return layout(`<h2>${esc(st.nama)}</h2>
  <div class="card"><b>Verifikasi Kode Ambil</b><label for="kode">Kode dari pembeli</label><input id="kode" autocapitalize="characters" autocomplete="off" maxlength="12" placeholder="mis. K7H2PQ">
  <button class="btn" data-act="verify">Verifikasi</button>${flashHtml()}</div>
  <button class="btn warn" data-act="nav" data-to="tcreate">+ Buat listing</button>
  <h3>Pesanan masuk</h3>${orders || '<div class="card mu">Belum ada pesanan.</div>'}<h3>Listing saya</h3>${mine || '<div class="card mu">Belum ada listing.</div>'}`, 'tdash');
};

V.tcreate = () => {
  const d = draft || (draft = newDraft());
  return layout(`<h2>Buat listing</h2><label>Jenis</label>
  <div class="seg"><button class="${d.type === TIPE.KEJUTAN ? 'on' : ''}" data-act="setType" data-type="kejutan">Paket Kejutan</button><button class="${d.type === TIPE.ITEM ? 'on' : ''}" data-act="setType" data-type="item">Item Pilihan</button></div>
  ${d.type === TIPE.ITEM ? `<label for="f_nama">Nama produk</label><input id="f_nama" value="${esc(d.nama)}" maxlength="60">` : '<p class="mu">Isi kantong tidak perlu diisi dan tidak ditampilkan ke pembeli.</p>'}
  <label for="f_jumlah">Jumlah ${d.type === TIPE.KEJUTAN ? 'kantong' : ''}</label><input id="f_jumlah" type="number" inputmode="numeric" min="1" value="${esc(d.jumlah)}">
  <label for="f_harga">Harga satuan (Rp)</label><input id="f_harga" type="number" inputmode="numeric" min="1" value="${esc(d.harga)}">
  <div class="grid"><div><label for="f_start">Ambil mulai</label><input id="f_start" type="time" value="${esc(d.start)}"></div><div><label for="f_end">Ambil selesai</label><input id="f_end" type="time" value="${esc(d.end)}"></div></div>
  <div class="note">${esc(TERMS)}</div>${flashHtml()}<button class="btn" data-act="saveListing">Simpan listing</button>`, 'tcreate');
};

function render() {
  try {
    if (corrupt) { app.innerHTML = V.corrupt(); return; }
    if (expireOrders(state, now()) > 0) save(state);
    app.innerHTML = (V[view.name] || V.role)();
  } catch (e) { fatal(e); }
}

function fatal(e) {
  console.error(e);
  app.innerHTML = `<div class="demo">MODE DEMO</div><main><h2>Terjadi kendala</h2><p>Aplikasi tetap aman. Anda bisa kembali ke beranda atau mereset data demo.</p>
  <button class="btn" data-act="home">Kembali ke beranda</button><button class="btn sec" data-act="reset">Reset demo</button></main>`;
}

function hhmm(ms) { const d = new Date(ms), t = new Date(now()); return d.getDate() !== t.getDate() ? '23:59' : jam(ms); }
function newDraft() { return { type: TIPE.KEJUTAN, nama: '', jumlah: '5', harga: '15000', start: hhmm(now() + 0.5 * HOUR), end: hhmm(now() + 3 * HOUR) }; }

const A = {
  roles() { ui.role = null; saveUi(ui); go('role'); },
  home() { go(ui.role === 'toko' ? 'tdash' : ui.role === 'pembeli' ? 'home' : 'role'); },
  pickRole(el) {
    const sel = document.getElementById('storeSel');
    ui = { role: el.dataset.role, storeId: sel ? sel.value : ui.storeId };
    saveUi(ui); go(ui.role === 'toko' ? 'tdash' : 'home');
  },
  nav(el) { if (el.dataset.to === 'tcreate') draft = newDraft(); go(el.dataset.to); },
  detail(el) { go('detail', { id: el.dataset.id, n: 1 }); },
  toConfirm(el) {
    const l = state.listings.find(x => x.id === el.dataset.id);
    const n = Number(document.getElementById('qty').value);
    let msg = null;
    if (!Number.isInteger(n) || n < 1) msg = 'Jumlah minimal 1 dan harus bilangan bulat.';
    else if (l && n > l.stok) msg = `Stok tersedia hanya ${l.stok}.`;
    if (msg) { view = { name: 'detail', id: el.dataset.id, n: Number.isFinite(n) ? n : 1 }; flash = { ok: false, msg }; render(); return; }
    go('confirm', { id: el.dataset.id, n });
  },
  pay(el) {
    const r = placeOrder(state, el.dataset.id, Number(el.dataset.n), now());
    if (!r.ok) { toast(r.error); go('home'); return; }
    save(state); go('order', { id: r.order.id });
  },
  openOrder(el) { go('order', { id: el.dataset.id }); },
  setType(el) { draft.type = el.dataset.type; flash = null; render(); },
  saveListing() {
    const t = now();
    const input = { type: draft.type, nama: draft.nama, jumlah: Number(draft.jumlah), harga: Number(draft.harga),
      ambilStart: todayAt(draft.start, t), ambilEnd: todayAt(draft.end, t) };
    const r = createListing(state, ui.storeId, input, t);
    if (!r.ok) { flash = { ok: false, html: r.errors.map(esc).join('<br>') }; render(); return; }
    save(state); toast('Listing dibuat dan tampil untuk Pembeli.'); go('tdash');
  },
  verify() {
    const r = verifyCode(state, ui.storeId, document.getElementById('kode').value, now());
    save(state);
    flash = r.ok ? { ok: true, msg: `Berhasil: ${r.order.judul} × ${r.order.qty} (${rp(r.order.total)}) ditandai Diambil.` } : { ok: false, msg: r.error };
    render();
  },
  advance() { state.meta.offsetMs += HOUR; save(state); render(); toast('Jam simulasi maju 1 jam.'); },
  reset(el) {
    if (!el.dataset.force && !window.confirm('Reset demo? Semua pesanan dan listing baru akan dihapus.')) return;
    state = reset(Date.now()); corrupt = false; noStorage = false; ui = { role: null, storeId: 's1' };
    view = { name: 'role' }; flash = null; render(); toast('Demo dikembalikan ke kondisi awal.');
  },
};

app.addEventListener('click', e => {
  const el = e.target.closest('[data-act]');
  if (!el || !A[el.dataset.act]) return;
  try { A[el.dataset.act](el); } catch (err) { fatal(err); }
});

app.addEventListener('input', e => {
  const t = e.target;
  if (t.id === 'qty') {
    const n = Number(t.value), price = Number(t.dataset.price), out = document.getElementById('totalTxt');
    if (out) out.textContent = Number.isInteger(n) && n > 0 ? rp(price * n) : '–';
  } else if (t.id && t.id.startsWith('f_') && draft) {
    draft[t.id.slice(2)] = t.value;
  }
});

window.addEventListener('error', e => fatal(e.error || e.message));
window.addEventListener('unhandledrejection', e => fatal(e.reason));
render();
